package com.example.cricketscorer;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class MatchCardController {

    @FXML private Label matchLabel;
    @FXML private Button viewButton;

    private Match match;
    private String tournamentFile;

    // Remove the single-parameter method to prevent null tournament file
    // Always require tournament file path
    public void setMatch(Match match, String tournamentFile) {
        if (tournamentFile == null || tournamentFile.trim().isEmpty()) {
            throw new IllegalArgumentException("Tournament file path cannot be null or empty");
        }

        this.match = match;
        this.tournamentFile = tournamentFile;
        matchLabel.setText(match.toString());

        viewButton.setOnAction(e -> openMatchView());
    }

    // FIXED: Method to check if match has actual bowling data (not just empty entries)
    private boolean hasActualMatchData() {
        try {
            List<String> lines = Files.readAllLines(Paths.get(tournamentFile));
            boolean foundMatch = false;
            int lineIndex = 0;

            // Find the current match in the file
            for (int i = 0; i < lines.size(); i++) {
                String line = lines.get(i);
                if (line.contains("|") && line.contains(match.getTeamAName()) &&
                        line.contains(match.getTeamBName())) {
                    foundMatch = true;
                    lineIndex = i;
                    break;
                }
            }

            if (foundMatch && lineIndex + 7 < lines.size()) {
                // Check team A batting and team B bowling data (first innings)
                String teamABatting = lines.get(lineIndex + 4);
                String teamBBowling = lines.get(lineIndex + 5);

                // Check team B batting and team A bowling data (second innings)
                String teamBBatting = lines.get(lineIndex + 6);
                String teamABowling = lines.get(lineIndex + 7);

                // Check if there's actual bowling data (not just empty or whitespace)
                boolean hasFirstInningsData = hasValidBowlingData(teamBBowling);
                boolean hasSecondInningsData = hasValidBowlingData(teamABowling);

                // Also check if batting lineups exist
                boolean hasFirstInningsBatting = teamABatting != null && !teamABatting.trim().isEmpty();
                boolean hasSecondInningsBatting = teamBBatting != null && !teamBBatting.trim().isEmpty();

                // Match has actual data if:
                // 1. First innings has started (batting lineup exists and has some bowling data)
                // 2. OR second innings has started
                return (hasFirstInningsBatting && hasFirstInningsData) ||
                        (hasSecondInningsBatting && hasSecondInningsData);
            }

            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    // FIXED: Helper method to check if bowling data contains actual balls (not just bowler names)
    private boolean hasValidBowlingData(String bowlingData) {
        if (bowlingData == null || bowlingData.trim().isEmpty()) {
            return false;
        }

        // Split by spaces to get individual bowler entries
        String[] bowlerEntries = bowlingData.trim().split("\\s+");

        for (String entry : bowlerEntries) {
            if (entry.contains("|")) {
                String[] parts = entry.split("\\|", 2);
                if (parts.length == 2) {
                    String ballSequence = parts[1].trim();
                    // Check if there are actual balls recorded (not just empty after |)
                    if (!ballSequence.isEmpty()) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    private void openMatchView() {
        try {
            String fxmlFile;
            String windowTitle;
            // FIXED: Determine which view to show based on match status, user type, and actual match data
            if (match.finished() || LogIn.viewer) {
                // Show read-only match view for finished matches or viewers
                fxmlFile = "match-view.fxml";
                windowTitle = "Match Details";
            } else if (hasActualMatchData()) {
                // FIXED: Show current match scoring interface only for ongoing matches with actual data
                fxmlFile = "current-match.fxml";
                windowTitle = "Live Match Scoring";
            } else {
                // FIXED: For new matches without data, also show current-match.fxml (it will handle player selection)
                fxmlFile = "current-match.fxml";
                windowTitle = "New Match Setup";
            }

            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Scene scene = new Scene(loader.load());

            if (fxmlFile.equals("match-view.fxml")) {
                // For match-view.fxml
                MatchViewController controller = loader.getController();
                controller.setMatch(match);
            } else {
                // For current-match.fxml
                CurrentMatchController controller = loader.getController();
                controller.setMatch(match, tournamentFile);
            }

            Stage stage = new Stage();
            stage.setTitle(windowTitle);
            stage.setScene(scene);
            stage.show();

        } catch (Exception ex) {
            ex.printStackTrace();
            // Fallback to match-view if current-match fails to load
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("match-view.fxml"));
                Scene scene = new Scene(loader.load());

                MatchViewController controller = loader.getController();
                controller.setMatch(match);

                Stage stage = new Stage();
                stage.setTitle("Match Details");
                stage.setScene(scene);
                stage.show();
            } catch (Exception fallbackEx) {
                fallbackEx.printStackTrace();
            }
        }
    }

    // Getter for match (in case other classes need access)
    public Match getMatch() {
        return match;
    }

    // Getter for tournament file
    public String getTournamentFile() {
        return tournamentFile;
    }
}