module com.example.cricketscorer {
    requires javafx.controls;
    requires javafx.fxml;
    requires jdk.compiler;

    opens com.example.cricketscorer to javafx.fxml;
    exports com.example.cricketscorer;
}