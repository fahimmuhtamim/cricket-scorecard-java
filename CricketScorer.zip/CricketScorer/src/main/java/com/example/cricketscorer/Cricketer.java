package com.example.cricketscorer;

public class Cricketer {
    private String name;
    private String team;

    public Cricketer(String name, String team) {
        this.name = name;
        this.team = team;
    }

    // Basic getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTeam() {
        return team;
    }

    public void setTeam(String team) {
        this.team = team;
    }

    @Override
    public String toString() {
        return "Cricketer{name='" + name + "', team='" + team + "}";
    }
}
