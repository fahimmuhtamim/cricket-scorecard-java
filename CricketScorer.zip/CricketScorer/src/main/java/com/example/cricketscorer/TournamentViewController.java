package com.example.cricketscorer;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.io.IOException;

public class TournamentViewController {

    @FXML
    private VBox matchListVBox;

    private Tournament tournament;

    public void setTournament(Tournament tournament) {
        this.tournament = tournament;
        showMatches();
    }

    private void showMatches() {
        matchListVBox.getChildren().clear();

        Label title = new Label("Previous Matches");
        title.setStyle("-fx-font-weight: bold; -fx-font-size: 18;");
        matchListVBox.getChildren().add(title);

        for (Match match : tournament.getMatches()) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("match-card.fxml"));
                HBox card = loader.load();
                MatchCardController controller = loader.getController();
                controller.setMatch(match);
                matchListVBox.getChildren().add(card);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
