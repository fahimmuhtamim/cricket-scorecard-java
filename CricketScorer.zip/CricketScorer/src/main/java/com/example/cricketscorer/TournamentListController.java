package com.example.cricketscorer;

import com.example.cricketscorer.sync.SyncIntegrationManager;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.util.Duration;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class TournamentListController {

    @FXML private VBox tournamentListVBox;
    @FXML private Button createNewTournamentButton;
    @FXML private Label syncStatusLabel;
    @FXML private Button refreshButton;
    @FXML private Button syncSettingsButton;

    private SyncIntegrationManager syncManager;
    private final String INDEX_FILE = "tournaments.txt";

    @FXML
    private void initialize() {
        // Initialize sync manager
        syncManager = SyncIntegrationManager.getInstance();

        // Set up sync callbacks
        setupSyncCallbacks();

        // Initialize sync connection
        syncManager.initializeSync();

        // Load tournaments
        loadTournaments();

        // Update sync status
        updateSyncStatus();
    }

    private void setupSyncCallbacks() {
        // Update tournament list when tournaments.txt changes
        syncManager.setTournamentListUpdateCallback(filename -> {
            Platform.runLater(() -> {
                System.out.println("Received tournament list update notification");
                loadTournaments();
                showNotification("Tournament list updated from network");
            });
        });

        // Update sync status when connection changes
        syncManager.setConnectionStatusCallback(() -> {
            Platform.runLater(this::updateSyncStatus);
        });
    }

    private void updateSyncStatus() {
        if (syncStatusLabel != null) {
            if (syncManager.isConnected()) {
                syncStatusLabel.setText("🟢 Connected");
                syncStatusLabel.setStyle("-fx-text-fill: green;");
            } else {
                syncStatusLabel.setText("🔴 Offline");
                syncStatusLabel.setStyle("-fx-text-fill: red;");
            }
        }
    }

    private void showNotification(String message) {
        // Simple notification - you could enhance this with a proper notification system
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Network Update");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.show();

        // Auto-close after 3 seconds
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(3), e -> alert.close()));
        timeline.play();
    }

    private void loadTournaments() {
        tournamentListVBox.getChildren().clear();

        File indexFile = new File(INDEX_FILE);
        if (!indexFile.exists()) {
            Label noTournamentsLabel = new Label("No tournaments found. Create a new tournament to get started.");
            noTournamentsLabel.setStyle("-fx-font-style: italic; -fx-text-fill: gray;");
            tournamentListVBox.getChildren().add(noTournamentsLabel);
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(indexFile))) {
            String filename;
            while ((filename = reader.readLine()) != null) {
                filename = filename.trim();
                if (!filename.isEmpty()) {
                    createTournamentButton(filename);
                }
            }

            if (tournamentListVBox.getChildren().isEmpty()) {
                Label noTournamentsLabel = new Label("No tournaments found. Create a new tournament to get started.");
                noTournamentsLabel.setStyle("-fx-font-style: italic; -fx-text-fill: gray;");
                tournamentListVBox.getChildren().add(noTournamentsLabel);
            }

        } catch (IOException e) {
            System.err.println("Error loading tournaments: " + e.getMessage());
            Label errorLabel = new Label("Error loading tournaments: " + e.getMessage());
            errorLabel.setStyle("-fx-text-fill: red;");
            tournamentListVBox.getChildren().add(errorLabel);
        }
    }

    private void createTournamentButton(String filename) {
        try {
            Tournament tournament = Tournament.loadFromFile(filename);

            Button tournamentButton = new Button();
            tournamentButton.setText(tournament.getName());
            tournamentButton.setMaxWidth(Double.MAX_VALUE);
            tournamentButton.setStyle("-fx-font-size: 14px; -fx-padding: 10px;");

            // Add match count and status info
            int matchCount = tournament.getMatches().size();
            int completedMatches = (int) tournament.getMatches().stream()
                    .mapToLong(match -> match.finished() ? 1 : 0)
                    .sum();

            String statusText = String.format("%s\n%d matches (%d completed)",
                    tournament.getName(), matchCount, completedMatches);
            tournamentButton.setText(statusText);

            tournamentButton.setOnAction(e -> openTournament(filename, tournament));

            // Add context menu for additional options
            ContextMenu contextMenu = new ContextMenu();

            MenuItem openItem = new MenuItem("Open Tournament");
            openItem.setOnAction(e -> openTournament(filename, tournament));

            MenuItem refreshItem = new MenuItem("Refresh from Network");
            refreshItem.setOnAction(e -> {
                syncManager.requestFile(filename);
                showNotification("Requesting latest version of " + tournament.getName());
            });

            MenuItem syncItem = new MenuItem("Force Sync");
            syncItem.setOnAction(e -> {
                syncManager.notifyTournamentUpdate(filename);
                showNotification("Syncing " + tournament.getName() + " to network");
            });

            contextMenu.getItems().addAll(openItem, refreshItem, syncItem);
            tournamentButton.setContextMenu(contextMenu);

            tournamentListVBox.getChildren().add(tournamentButton);

        } catch (IOException e) {
            System.err.println("Error loading tournament " + filename + ": " + e.getMessage());

            Button errorButton = new Button("Error loading: " + filename);
            errorButton.setStyle("-fx-text-fill: red; -fx-font-size: 12px;");
            errorButton.setDisable(true);
            tournamentListVBox.getChildren().add(errorButton);
        }
    }

    private void openTournament(String filename, Tournament tournament) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("tournament-view.fxml"));
            Parent root = loader.load();

            TournamentViewController controller = loader.getController();
            controller.setTournament(tournament);
            controller.setTournamentFile(filename);

            Stage stage = (Stage) tournamentListVBox.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setTitle("Tournament: " + tournament.getName());
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            showErrorAlert("Error opening tournament: " + e.getMessage());
        }
    }

    @FXML
    private void handleCreateNewTournament(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("new-tournament.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setTitle("Create New Tournament");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            showErrorAlert("Error opening new tournament form: " + e.getMessage());
        }
    }

    @FXML
    private void handleRefresh(ActionEvent event) {
        // Request fresh tournament list from server
        syncManager.requestFile("tournaments.txt");

        // Also request updates for all tournament files
        syncManager.forceFullSync();

        showNotification("Requesting latest data from network...");
    }

    @FXML
    private void handleSyncSettings(ActionEvent event) {
        showSyncSettingsDialog();
    }

    private void showSyncSettingsDialog() {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Sync Settings");
        dialog.setHeaderText("Network Synchronization Settings");

        VBox content = new VBox(10);

        // Server host
        TextField hostField = new TextField(syncManager.getConfig().getServerHost());
        content.getChildren().addAll(new Label("Server Host:"), hostField);

        // Server port
        TextField portField = new TextField(String.valueOf(syncManager.getConfig().getServerPort()));
        content.getChildren().addAll(new Label("Server Port:"), portField);

        // Enable/disable sync
        CheckBox enableSyncBox = new CheckBox("Enable network synchronization");
        enableSyncBox.setSelected(syncManager.getConfig().isSyncEnabled());
        content.getChildren().add(enableSyncBox);

        // Connection status
        Label statusLabel = new Label("Current Status: " + syncManager.getConnectionStatus());
        content.getChildren().add(statusLabel);

        dialog.getDialogPane().setContent(content);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.showAndWait().ifPresent(result -> {
            if (result == ButtonType.OK) {
                // Save settings
                syncManager.getConfig().setServerHost(hostField.getText().trim());
                try {
                    syncManager.getConfig().setServerPort(Integer.parseInt(portField.getText().trim()));
                } catch (NumberFormatException e) {
                    showErrorAlert("Invalid port number");
                    return;
                }

                syncManager.setSyncEnabled(enableSyncBox.isSelected());

                showNotification("Sync settings updated");
                updateSyncStatus();
            }
        });
    }

    private void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Clean up when controller is destroyed
    public void cleanup() {
        if (syncManager != null) {
            // Don't disconnect here as other controllers might be using it
            // syncManager.disconnect();
        }
    }
}