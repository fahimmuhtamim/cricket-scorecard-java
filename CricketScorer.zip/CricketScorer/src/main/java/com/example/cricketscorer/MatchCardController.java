package com.example.cricketscorer;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class MatchCardController {

    @FXML private Label matchLabel;
    @FXML private Button viewButton;

    private Match match;

    public void setMatch(Match match) {
        this.match = match;
        matchLabel.setText(match.toString());

        viewButton.setOnAction(e -> openMatchDetailView());
    }

    private void openMatchDetailView() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("match-view.fxml"));
            Scene scene = new Scene(loader.load());

            MatchViewController controller = loader.getController();
            controller.setMatch(match);

            Stage stage = new Stage();
            stage.setTitle("Match Details");
            stage.setScene(scene);
            stage.show();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
