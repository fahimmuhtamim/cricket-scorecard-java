package com.example.cricketscorer;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class MatchCardController {

    @FXML
    private Label teamsLabel;

    @FXML
    private Label statusLabel;

    public void setMatch(Match match) {
        teamsLabel.setText(match.getTeamAName() + " vs " + match.getTeamBName());
        statusLabel.setText("Players: " + match.getTeamA().size() + " vs " + match.getTeamB().size());
    }
}
