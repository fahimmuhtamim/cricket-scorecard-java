package com.example.cricketscorer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Tournament {
    private Map<String, List<Player>> teams;
    private List<Match> matches;

    public Tournament() {
        this.teams = new HashMap<>();
        this.matches = new ArrayList<>();
    }

    public void createEmptyTeam(String teamName) {
        if (!teams.containsKey(teamName)) {
            teams.put(teamName, new ArrayList<>());
        }
    }

    public boolean addPlayerToTeam(String teamName, Player player) {
        List<Player> team = teams.get(teamName);
        if (team != null && team.size() < 11) {
            team.add(player);
            return true;
        }
        return false;
    }

    public List<Player> getTeam(String teamName) {
        return teams.getOrDefault(teamName, new ArrayList<>());
    }

    public void scheduleMatch(String teamAName, String teamBName) {
        if (teams.containsKey(teamAName) && teams.containsKey(teamBName)) {
            Match match = new Match(teamAName, teamBName);
            // You can clone or directly assign players here if needed
            for (Player p : teams.get(teamAName)) {
                match.addPlayerToTeamA(p);
            }
            for (Player p : teams.get(teamBName)) {
                match.addPlayerToTeamB(p);
            }
            matches.add(match);
        }
    }

    public List<Match> getMatches() {
        return matches;
    }

    public Map<String, List<Player>> getTeams() {
        return teams;
    }
}
