package com.example.cricketscorer;

import java.io.*;
import java.time.LocalDate;
import java.util.*;

public class Tournament {
    private String name;
    private LocalDate createdDate;
    private Map<String, List<Player>> teams;
    private List<Match> matches;

    public Tournament(String name) {
        this.name = name;
        this.createdDate = LocalDate.now();
        this.teams = new HashMap<>();
        this.matches = new ArrayList<>();
    }

    public Tournament() {
        this.teams = new HashMap<>();
        this.matches = new ArrayList<>();
    }

    public void createEmptyTeam(String teamName) {
        teams.putIfAbsent(teamName, new ArrayList<>());
    }

    public boolean addPlayerToTeam(String teamName, Player player) {
        List<Player> team = teams.get(teamName);
        if (team != null && team.size() < 11) {
            team.add(player);
            return true;
        }
        return false;
    }

    public void scheduleMatch(String teamA, String teamB) {
        Match m = new Match(teamA, teamB);
        m.setTeamA(teams.getOrDefault(teamA, new ArrayList<>()));
        m.setTeamB(teams.getOrDefault(teamB, new ArrayList<>()));
        matches.add(m);
    }

    public void saveToFile(String filename) throws IOException {
        try (PrintWriter out = new PrintWriter(new FileWriter(filename))) {
            out.println(name);
            out.println("Date: " + createdDate);
            out.println("Teams:");
            for (Map.Entry<String, List<Player>> entry : teams.entrySet()) {
                out.println(entry.getKey());
                for (Player p : entry.getValue()) {
                    out.println("  - " + p.getName());
                }
            }
            out.println("Matches:");
            for (Match m : matches) {
                out.println(m.getTeamAName() + " | " + m.getTeamBName());

                out.println(String.join("|", m.getTeamA().stream().map(Player::getName).toArray(String[]::new)));
                out.println(String.join("|", m.getTeamB().stream().map(Player::getName).toArray(String[]::new)));

                // Dummy lines for batting/bowling - you can customize this
                out.println(String.join("|", m.getBattingA()));
                out.println(String.join("|", m.getBowlingA()));
                out.println(String.join("|", m.getBattingB()));
                out.println(String.join("|", m.getBowlingB()));
            }
        }
    }


    public static Tournament loadFromFile(String filename) throws IOException {
        Tournament t = new Tournament();

        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            // 1. Tournament Name
            t.name = br.readLine();

            // 2. Date
            String dateLine = br.readLine();
            if (dateLine != null && dateLine.startsWith("Date: ")) {
                t.createdDate = LocalDate.parse(dateLine.substring(6).trim());
            }

            // 3. Find "Teams:"
            String line;
            while ((line = br.readLine()) != null && !line.equals("Teams:")) {
                // Skip until "Teams:"
            }

            // 4. Read team names until "Matches:"
            while ((line = br.readLine()) != null && !line.equals("Matches:")) {
                if (!line.trim().isEmpty()) {
                    t.createEmptyTeam(line.trim());
                }
            }

            // 5. Parse Matches
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;

                // Team names line (e.g., "India|Pakistan")
                String[] teamNames = line.split("\\|");
                if (teamNames.length != 2) continue;

                String teamAName = teamNames[0].trim();
                String teamBName = teamNames[1].trim();

                // Read the 6 lines for this match
                String teamAPlayers = br.readLine(); // Team A players
                String teamBPlayers = br.readLine(); // Team B players
                String teamABatting = br.readLine(); // Team A batting lineup
                String teamABowling = br.readLine(); // Team A bowling stats (Team B bowling against A)
                String teamBBatting = br.readLine(); // Team B batting lineup
                String teamBBowling = br.readLine(); // Team B bowling stats (Team A bowling against B)

                // Parse the data
                List<String> teamABattingList = parsePlayerList(teamABatting);
                List<String> teamBBowlingList = parseBowlingStats(teamABowling);
                List<String> teamBBattingList = parsePlayerList(teamBBatting);
                List<String> teamABowlingList = parseBowlingStats(teamBBowling);

                // Create match with parsed data
                Match match = new Match(
                        teamAName,
                        teamBName,
                        teamABattingList,
                        teamBBowlingList,
                        teamBBattingList,
                        teamABowlingList,
                        "" // Overview will be generated from bowling stats
                );

                // Set team players
                match.setTeamA(parsePlayersToObjects(teamAPlayers));
                match.setTeamB(parsePlayersToObjects(teamBPlayers));

                // Generate overview from bowling data
                String overview = generateOverview(teamABowling, teamBBowling);
                match.setOverview(overview);

                t.matches.add(match);
            }
        }
        return t;
    }

    private static List<String> parsePlayerList(String line) {
        List<String> result = new ArrayList<>();
        if (line == null || line.trim().isEmpty()) return result;

        String[] players = line.split("\\|");
        for (String player : players) {
            if (!player.trim().isEmpty()) {
                result.add(player.trim());
            }
        }
        return result;
    }

    private static List<String> parseBowlingStats(String line) {
        List<String> result = new ArrayList<>();
        if (line == null || line.trim().isEmpty()) return result;

        // Split by bowler (each bowler's stats are separated by space before name)
        String[] segments = line.split("(?=\\b[A-Z][a-z]+\\|)");

        for (String segment : segments) {
            if (segment.trim().isEmpty()) continue;

            // Parse bowler name and their bowling figures
            String[] parts = segment.split("\\|", 2);
            if (parts.length == 2) {
                String bowlerName = parts[0].trim();
                String bowlingFigures = parts[1].trim();
                result.add(bowlerName + ": " + bowlingFigures);
            }
        }
        return result;
    }

    private static List<Player> parsePlayersToObjects(String line) {
        List<Player> players = new ArrayList<>();
        if (line == null || line.trim().isEmpty()) return players;

        String[] names = line.split("\\|");
        for (String name : names) {
            if (!name.trim().isEmpty()) {
                players.add(new Player(name.trim()));
            }
        }
        return players;
    }

    private static String generateOverview(String teamABowling, String teamBBowling) {
        StringBuilder overview = new StringBuilder();
        overview.append("Match Commentary:\n\n");

        if (teamABowling != null && !teamABowling.isEmpty()) {
            overview.append("First Innings Bowling:\n");
            overview.append(formatBowlingForOverview(teamABowling));
            overview.append("\n\n");
        }

        if (teamBBowling != null && !teamBBowling.isEmpty()) {
            overview.append("Second Innings Bowling:\n");
            overview.append(formatBowlingForOverview(teamBBowling));
        }

        return overview.toString();
    }

    private static String formatBowlingForOverview(String bowlingLine) {
        StringBuilder formatted = new StringBuilder();
        String[] segments = bowlingLine.split("(?=\\b[A-Z][a-z]+\\|)");

        for (String segment : segments) {
            if (segment.trim().isEmpty()) continue;

            String[] parts = segment.split("\\|", 2);
            if (parts.length == 2) {
                String bowlerName = parts[0].trim();
                String balls = parts[1].trim();
                formatted.append(bowlerName).append(": ").append(balls).append("\n");
            }
        }

        return formatted.toString();
    }

    public String getName() { return name; }
    public LocalDate getCreatedDate() { return createdDate; }
    public List<Match> getMatches() { return matches; }
    public List<String> getTeamNames() { return new ArrayList<>(teams.keySet()); }
    public Map<String, List<Player>> getTeams() { return teams; }
}
