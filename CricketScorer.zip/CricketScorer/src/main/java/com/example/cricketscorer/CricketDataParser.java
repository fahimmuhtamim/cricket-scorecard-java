package com.example.cricketscorer;

import java.util.ArrayList;
import java.util.List;

public class CricketDataParser {

    public static List<String> parseBowlingStats(String bowlingLine) {
        List<String> bowlingStats = new ArrayList<>();
        if (bowlingLine == null || bowlingLine.trim().isEmpty()) {
            return bowlingStats;
        }

        // Method to calculate individual batting scores from bowling data

        // Split the line by looking for pattern: Name|stats
        String[] segments = bowlingLine.split("(?=\\b[A-Z][a-z]+\\|)");

        for (String segment : segments) {
            segment = segment.trim();
            if (segment.isEmpty()) continue;

            // Find the position of the first "|" after a capital letter name
            int pipeIndex = segment.indexOf('|');
            if (pipeIndex != -1) {
                String bowlerName = segment.substring(0, pipeIndex).trim();
                String ballSequence = segment.substring(pipeIndex + 1).trim();

                if (!bowlerName.isEmpty() && !ballSequence.isEmpty()) {
                    bowlingStats.add(bowlerName + ": " + ballSequence);
                }
            }
        }

        return bowlingStats;
    }
    public static java.util.Map<String, Integer> calculateBattingScores(java.util.List<String> battingLineup, java.util.List<String> bowlingData) {

        java.util.Map<String, Integer> battingScores = new java.util.HashMap<>();

        // Initialize all batsmen with 0 runs
        for (String batsman : battingLineup) {
            battingScores.put(batsman, 0);
        }

        if (battingLineup.isEmpty() || bowlingData.isEmpty()) {
            return battingScores;
        }

        int currentBatsmanIndex = 0;
        String currentBatsman = battingLineup.get(0);
        String nonStriker = battingLineup.size() > 1 ? battingLineup.get(1) : null;

        // Process each bowler's data
        for (String bowlerStats : bowlingData) {
            if (!bowlerStats.contains(":")) continue;

            String[] parts = bowlerStats.split(":", 2);
            String ballSequence = parts[1].trim();
            String[] balls = ballSequence.split("\\s+");

            // Process each ball
            for (String ball : balls) {
                ball = ball.trim();
                if (ball.isEmpty()) continue;

                if (ball.equals("wk")) {
                    // Current batsman is out, next batsman comes in
                    currentBatsmanIndex++;
                    if (currentBatsmanIndex < battingLineup.size()) {
                        currentBatsman = battingLineup.get(currentBatsmanIndex);
                    }
                } else if (ball.startsWith("wd") || ball.startsWith("nb") || ball.startsWith("b+")) {
                    // Extras - no runs to batsman, no strike change
                    continue;
                } else if (ball.matches("\\d+")) {
                    // Regular runs off the bat
                    int runs = Integer.parseInt(ball);
                    battingScores.put(currentBatsman, battingScores.get(currentBatsman) + runs);

                    // Change strike if odd number of runs
                    if (runs % 2 == 1 && nonStriker != null) {
                        String temp = currentBatsman;
                        currentBatsman = nonStriker;
                        nonStriker = temp;
                    }
                } else if (ball.contains("+")) {
                    // Handle formats like "1+wk", "4+wk"
                    String[] ballParts = ball.split("\\+");
                    if (ballParts.length == 2 && ballParts[0].matches("\\d+")) {
                        int runs = Integer.parseInt(ballParts[0]);
                        battingScores.put(currentBatsman, battingScores.get(currentBatsman) + runs);

                        // Check if it's a wicket
                        if (ballParts[1].equals("wk")) {
                            currentBatsmanIndex++;
                            if (currentBatsmanIndex < battingLineup.size()) {
                                currentBatsman = battingLineup.get(currentBatsmanIndex);
                            }
                        } else {
                            // Change strike if odd runs and no wicket
                            if (runs % 2 == 1 && nonStriker != null) {
                                String temp = currentBatsman;
                                currentBatsman = nonStriker;
                                nonStriker = temp;
                            }
                        }
                    }
                }
                // For dot balls (0, .), no runs added and no strike change
            }
        }

        return battingScores;
    }


    public static BowlingFigures calculateBowlingFigures(String ballSequence) {
        String[] balls = ballSequence.split("\\s+");
        int bowlerRuns = 0, teamRuns = 0, wickets = 0, ballsBowled = 0, wides = 0, byes = 0, noBalls = 0;

        for (String ball : balls) {
            ball = ball.trim();
            if (ball.isEmpty()) continue;

            if (ball.equals("wk")) {
                // Wicket - no runs, counts as a ball
                wickets++;
                ballsBowled++;
            } else if (ball.equals("wd")) {
                // Wide - 1 run to team, 1 run against bowler, doesn't count as a ball
                bowlerRuns += 1;
                teamRuns += 1;
                wides++;
            } else if (ball.startsWith("wd+")) {
                // Wide with additional runs (e.g., wd+4 = wide + 4 runs = 5 total)
                String runsStr = ball.substring(3);
                if (runsStr.matches("\\d+")) {
                    int additionalRuns = Integer.parseInt(runsStr);
                    bowlerRuns += 1 + additionalRuns; // All runs against bowler
                    teamRuns += 1 + additionalRuns;
                    wides++;
                }
            } else if (ball.startsWith("b+")) {
                // Byes - runs to team total, NOT against bowler, counts as a ball
                String runsStr = ball.substring(2);
                if (runsStr.matches("\\d+")) {
                    int byeRuns = Integer.parseInt(runsStr);
                    teamRuns += byeRuns; // Only to team total
                    byes += byeRuns;
                    ballsBowled++;
                    // bowlerRuns += 0; // Byes don't count against bowler
                }
            } else if (ball.equals("nb")) {
                // No ball - 1 run to team and against bowler, doesn't count as a ball
                bowlerRuns += 1;
                teamRuns += 1;
                noBalls++;
            } else if (ball.startsWith("nb+")) {
                // No ball with additional runs (e.g., nb+4 = no ball + 4 runs = 5 total)
                String runsStr = ball.substring(3);
                if (runsStr.matches("\\d+")) {
                    int additionalRuns = Integer.parseInt(runsStr);
                    bowlerRuns += 1 + additionalRuns; // All runs against bowler
                    teamRuns += 1 + additionalRuns;
                    noBalls++;
                }
            } else if (ball.matches("\\d+")) {
                // Regular runs off the bat - counts against bowler and to team
                int runs = Integer.parseInt(ball);
                bowlerRuns += runs;
                teamRuns += runs;
                ballsBowled++;
            } else if (ball.contains("+")) {
                // Handle other formats like "1+wk" (1 run + wicket)
                String[] parts = ball.split("\\+");
                if (parts.length == 2) {
                    // First part should be runs
                    if (parts[0].matches("\\d+")) {
                        int runs = Integer.parseInt(parts[0]);
                        bowlerRuns += runs;
                        teamRuns += runs;
                        ballsBowled++;
                    }
                    // Second part could be wicket
                    if (parts[1].equals("wk")) {
                        wickets++;
                    }
                }
            } else if (ball.equals("0") || ball.equals(".")) {
                // Dot ball - no runs, counts as a ball
                ballsBowled++;
            } else {
                // Unknown format - assume it's a dot ball
                ballsBowled++;
            }
        }

        return new BowlingFigures(ballsBowled, bowlerRuns, teamRuns, wickets, wides, byes, noBalls);
    }

    public static class BowlingFigures {
        public final int balls;
        public final int bowlerRuns;  // Runs conceded by bowler (excludes byes)
        public final int teamRuns;    // Total runs added to team score
        public final int wickets;
        public final int wides;
        public final int byes;
        public final int noBalls;

        public BowlingFigures(int balls, int bowlerRuns, int teamRuns, int wickets, int wides, int byes, int noBalls) {
            this.balls = balls;
            this.bowlerRuns = bowlerRuns;
            this.teamRuns = teamRuns;
            this.wickets = wickets;
            this.wides = wides;
            this.byes = byes;
            this.noBalls = noBalls;
        }

        // Backward compatibility constructor
        public BowlingFigures(int balls, int runs, int wickets, int wides, int byes) {
            this(balls, runs, runs, wickets, wides, byes, 0);
        }

        public double getOvers() {
            return (balls / 6) + (balls % 6) * 0.1;
        }

        public double getEconomy() {
            return balls > 0 ? (bowlerRuns * 6.0) / balls : 0.0;
        }

        public String getOverString() {
            return (balls / 6) + "." + (balls % 6);
        }

        public int getTotalExtras() {
            return wides + byes + noBalls;
        }

        // For backward compatibility - use bowlerRuns
        public int getRuns() {
            return bowlerRuns;
        }

        @Override
        public String toString() {
            return String.format("Overs: %s, Runs: %d, Wickets: %d, Extras: %d (wd:%d, b:%d, nb:%d)",
                    getOverString(), bowlerRuns, wickets, getTotalExtras(), wides, byes, noBalls);
        }
    }
}