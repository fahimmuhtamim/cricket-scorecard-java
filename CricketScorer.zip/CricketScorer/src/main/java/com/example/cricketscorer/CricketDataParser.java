package com.example.cricketscorer;

import java.util.ArrayList;
import java.util.List;

public class CricketDataParser {

    public static List<String> parseBowlingStats(String bowlingLine) {
        List<String> bowlingStats = new ArrayList<>();
        if (bowlingLine == null || bowlingLine.trim().isEmpty()) {
            return bowlingStats;
        }

        // Split the line by looking for pattern: Name|stats
        String[] segments = bowlingLine.split("(?=\\b[A-Z][a-z]+\\|)");

        for (String segment : segments) {
            segment = segment.trim();
            if (segment.isEmpty()) continue;

            // Find the position of the first "|" after a capital letter name
            int pipeIndex = segment.indexOf('|');
            if (pipeIndex != -1) {
                String bowlerName = segment.substring(0, pipeIndex).trim();
                String ballSequence = segment.substring(pipeIndex + 1).trim();

                if (!bowlerName.isEmpty() && !ballSequence.isEmpty()) {
                    bowlingStats.add(bowlerName + ": " + ballSequence);
                }
            }
        }

        return bowlingStats;
    }

    public static BowlingFigures calculateBowlingFigures(String ballSequence) {
        String[] balls = ballSequence.split("\\s+");
        int runs = 0, wickets = 0, ballsBowled = 0, wides = 0, byes = 0;

        for (String ball : balls) {
            if (ball.equals("wk")) {
                wickets++;
                ballsBowled++;
            } else if (ball.equals("wd")) {
                runs++;
                wides++;
                // Wide doesn't count as a ball
            } else if (ball.startsWith("wd+")) {
                String runsStr = ball.substring(3);
                if (runsStr.matches("\\d+")) {
                    runs += Integer.parseInt(runsStr);
                    wides++;
                }
            } else if (ball.startsWith("b+")) {
                String runsStr = ball.substring(2);
                if (runsStr.matches("\\d+")) {
                    byes += Integer.parseInt(runsStr);
                    ballsBowled++;
                }
            } else if (ball.matches("\\d+")) {
                runs += Integer.parseInt(ball);
                ballsBowled++;
            } else if (ball.contains("+")) {
                // Handle other extras like nb+4, etc.
                String[] parts = ball.split("\\+");
                if (parts.length == 2 && parts[1].matches("\\d+")) {
                    runs += Integer.parseInt(parts[1]);
                    if (!parts[0].equals("wd")) {
                        ballsBowled++;
                    }
                }
            } else {
                // Assume it's a dot ball or unknown format
                ballsBowled++;
            }
        }

        return new BowlingFigures(ballsBowled, runs, wickets, wides, byes);
    }

    public static class BowlingFigures {
        public final int balls;
        public final int runs;
        public final int wickets;
        public final int wides;
        public final int byes;

        public BowlingFigures(int balls, int runs, int wickets, int wides, int byes) {
            this.balls = balls;
            this.runs = runs;
            this.wickets = wickets;
            this.wides = wides;
            this.byes = byes;
        }

        public double getOvers() {
            return (balls / 6) + (balls % 6) * 0.1;
        }

        public double getEconomy() {
            return balls > 0 ? (runs * 6.0) / balls : 0.0;
        }

        public String getOverString() {
            return (balls / 6) + "." + (balls % 6);
        }
    }
}