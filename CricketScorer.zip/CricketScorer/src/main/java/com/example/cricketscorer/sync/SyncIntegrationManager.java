package com.example.cricketscorer.sync;

import javafx.application.Platform;
import javafx.concurrent.Task;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.function.Consumer;

/**
 * Main integration point for sync functionality in the Cricket Scorer application.
 * This class manages the sync client and provides high-level methods for controllers.
 */
public class SyncIntegrationManager {
    private static SyncIntegrationManager instance;
    private FileSyncClient syncClient;
    private final String dataDirectory;

    // UI update callbacks
    private Consumer<String> tournamentListUpdateCallback;
    private Consumer<String> tournamentUpdateCallback;
    private Consumer<String> matchUpdateCallback;
    private Runnable connectionStatusCallback;

    private SyncIntegrationManager() {
        this.dataDirectory = System.getProperty("user.dir"); // Current working directory
        this.syncClient = new FileSyncClient(dataDirectory);
        setupCallbacks();
    }

    public static SyncIntegrationManager getInstance() {
        if (instance == null) {
            instance = new SyncIntegrationManager();
        }
        return instance;
    }

    private void setupCallbacks() {
        syncClient.setOnTournamentListUpdated(filename -> {
            System.out.println("Tournament list updated via sync: " + filename);
            if (tournamentListUpdateCallback != null) {
                tournamentListUpdateCallback.accept(filename);
            }
        });

        syncClient.setOnTournamentUpdated(filename -> {
            System.out.println("Tournament updated via sync: " + filename);
            if (tournamentUpdateCallback != null) {
                tournamentUpdateCallback.accept(filename);
            }
        });

        syncClient.setOnMatchUpdated(filename -> {
            System.out.println("Match updated via sync: " + filename);
            if (matchUpdateCallback != null) {
                matchUpdateCallback.accept(filename);
            }
        });

        syncClient.setOnConnectionStatusChanged(() -> {
            System.out.println("Sync connection status changed: " + isConnected());
            if (connectionStatusCallback != null) {
                connectionStatusCallback.run();
            }
        });
    }

    /**
     * Initialize sync connection in background
     */
    public void initializeSync() {
        Task<Boolean> connectTask = new Task<Boolean>() {
            @Override
            protected Boolean call() throws Exception {
                return syncClient.connect();
            }

            @Override
            protected void succeeded() {
                System.out.println("Sync initialization completed. Connected: " + getValue());
            }

            @Override
            protected void failed() {
                System.err.println("Sync initialization failed: " + getException().getMessage());
            }
        };

        Thread syncThread = new Thread(connectTask);
        syncThread.setDaemon(true);
        syncThread.start();
    }

    /**
     * Call this when a new tournament is created
     */
    public void notifyNewTournament(String tournamentFilename) {
        Task<Void> syncTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                // Sync the new tournament file
                Path tournamentPath = Paths.get(dataDirectory, tournamentFilename);
                if (Files.exists(tournamentPath)) {
                    String content = Files.readString(tournamentPath);
                    syncClient.notifyNewTournament(tournamentFilename, content);
                }

                // Sync the updated tournaments.txt
                syncClient.syncTournamentsList();

                return null;
            }

            @Override
            protected void failed() {
                System.err.println("Failed to sync new tournament: " + getException().getMessage());
            }
        };

        Thread thread = new Thread(syncTask);
        thread.setDaemon(true);
        thread.start();
    }

    /**
     * Call this when a new match is added to a tournament
     */
    public void notifyNewMatch(String tournamentFilename) {
        syncTournamentFile(tournamentFilename);
    }

    /**
     * Call this when match score/data is updated
     */
    public void notifyMatchUpdate(String tournamentFilename) {
        syncTournamentFile(tournamentFilename);
    }

    /**
     * Call this when tournament data changes (teams, matches, etc.)
     */
    public void notifyTournamentUpdate(String tournamentFilename) {
        syncTournamentFile(tournamentFilename);
    }

    private void syncTournamentFile(String tournamentFilename) {
        Task<Void> syncTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                Path tournamentPath = Paths.get(dataDirectory, tournamentFilename);
                if (Files.exists(tournamentPath)) {
                    String content = Files.readString(tournamentPath);
                    syncClient.notifyFileChange(tournamentFilename, content);
                }
                return null;
            }

            @Override
            protected void failed() {
                System.err.println("Failed to sync tournament file " + tournamentFilename +
                        ": " + getException().getMessage());
            }
        };

        Thread thread = new Thread(syncTask);
        thread.setDaemon(true);
        thread.start();
    }

    /**
     * Set callback for when tournament list (tournaments.txt) is updated
     */
    public void setTournamentListUpdateCallback(Consumer<String> callback) {
        this.tournamentListUpdateCallback = callback;
    }

    /**
     * Set callback for when a specific tournament file is updated
     */
    public void setTournamentUpdateCallback(Consumer<String> callback) {
        this.tournamentUpdateCallback = callback;
    }

    /**
     * Set callback for when match data is updated
     */
    public void setMatchUpdateCallback(Consumer<String> callback) {
        this.matchUpdateCallback = callback;
    }

    /**
     * Set callback for connection status changes
     */
    public void setConnectionStatusCallback(Runnable callback) {
        this.connectionStatusCallback = callback;
    }

    /**
     * Check if sync is currently connected
     */
    public boolean isConnected() {
        return syncClient != null && syncClient.isConnected();
    }

    /**
     * Get sync configuration
     */
    public SyncConfig getConfig() {
        return syncClient.getConfig();
    }

    /**
     * Manually request a file from server
     */
    public void requestFile(String filename) {
        if (syncClient != null) {
            syncClient.requestFile(filename);
        }
    }

    /**
     * Disconnect from sync server
     */
    public void disconnect() {
        if (syncClient != null) {
            syncClient.disconnect();
        }
    }

    /**
     * Force sync of all tournament data (useful for manual refresh)
     */
    public void forceFullSync() {
        Task<Void> syncTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                // Sync tournaments.txt
                syncClient.syncTournamentsList();

                // Sync all tournament files
                Path dir = Paths.get(dataDirectory);
                Files.list(dir)
                        .filter(path -> path.toString().endsWith(".txt"))
                        .filter(path -> !path.getFileName().toString().equals("tournaments.txt"))
                        .forEach(path -> {
                            try {
                                String content = Files.readString(path);
                                syncClient.notifyFileChange(path.getFileName().toString(), content);
                                Thread.sleep(100); // Small delay to prevent overwhelming server
                            } catch (Exception e) {
                                System.err.println("Error syncing " + path.getFileName() + ": " + e.getMessage());
                            }
                        });

                return null;
            }

            @Override
            protected void succeeded() {
                System.out.println("Full sync completed");
            }

            @Override
            protected void failed() {
                System.err.println("Full sync failed: " + getException().getMessage());
            }
        };

        Thread thread = new Thread(syncTask);
        thread.setDaemon(true);
        thread.start();
    }

    /**
     * Get connection status as string for UI display
     */
    public String getConnectionStatus() {
        if (isConnected()) {
            return "● Connected";
        } else {
            return "● Disconnected";
        }
    }

    /**
     * Enable or disable sync
     */
    public void setSyncEnabled(boolean enabled) {
        getConfig().setSyncEnabled(enabled);
        getConfig().saveConfig();

        if (enabled && !isConnected()) {
            initializeSync();
        } else if (!enabled && isConnected()) {
            disconnect();
        }
    }
}
