package com.example.cricketscorer;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Match implements Serializable {
    private String teamAName;
    private String teamBName;
    private List<Player> teamA;
    private List<Player> teamB;
    private List<String> teamABatting;
    private List<String> teamBBowling;
    private List<String> teamBBatting;
    private List<String> teamABowling;
    private String overview;

    public Match(String teamAName, String teamBName) {
        this.teamAName = teamAName;
        this.teamBName = teamBName;
        this.teamA = new ArrayList<>();
        this.teamB = new ArrayList<>();
        this.teamABatting = new ArrayList<>();
        this.teamBBowling = new ArrayList<>();
        this.teamBBatting = new ArrayList<>();
        this.teamABowling = new ArrayList<>();
        this.overview = "";
    }

    public Match(String teamAName, String teamBName, List<String> teamABatting, List<String> teamBBowling,
                 List<String> teamBBatting, List<String> teamABowling, String overview) {
        this.teamAName = teamAName;
        this.teamBName = teamBName;
        this.teamABatting = teamABatting;
        this.teamBBowling = teamBBowling;
        this.teamBBatting = teamBBatting;
        this.teamABowling = teamABowling;
        this.overview = overview;
        this.teamA = new ArrayList<>();
        this.teamB = new ArrayList<>();
    }

    public String getTeamAName() {
        return teamAName;
    }

    public String getTeamBName() {
        return teamBName;
    }

    public List<Player> getTeamA() {
        return teamA;
    }

    public List<Player> getTeamB() {
        return teamB;
    }

    public void setTeamA(List<Player> teamA) {
        this.teamA = teamA;
    }

    public void setTeamB(List<Player> teamB) {
        this.teamB = teamB;
    }

    public List<String> getBattingA() {
        return teamABatting;
    }

    public List<String> getBattingB() {
        return teamBBatting;
    }

    public List<String> getBowlingA() {
        return teamABowling;
    }

    public List<String> getBowlingB() {
        return teamBBowling;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    @Override
    public String toString() {
        return teamAName + " vs " + teamBName;
    }

    // Convert the match to a list of strings for writing to file
    public List<String> toFileString() {
        List<String> lines = new ArrayList<>();
        lines.add(teamAName);
        lines.add(teamBName);

        lines.add(String.join(",", playerNames(teamA)));
        lines.add(String.join(",", playerNames(teamB)));

        lines.add(String.join(",", teamABatting));
        lines.add(String.join(",", teamBBowling));
        lines.add(String.join(",", teamBBatting));
        lines.add(String.join(",", teamABowling));
        lines.add(overview.replace("\n", "\\n")); // Escape newlines
        lines.add("---"); // Separator
        return lines;
    }

    private List<String> playerNames(List<Player> players) {
        List<String> names = new ArrayList<>();
        for (Player p : players) {
            names.add(p.getName()); // assumes Player has getName()
        }
        return names;
    }

    // Load a match from a list of lines
    public static Match fromFileLines(List<String> lines) {
        String teamAName = lines.get(0);
        String teamBName = lines.get(1);

        List<Player> teamA = parsePlayers(lines.get(2));
        List<Player> teamB = parsePlayers(lines.get(3));

        List<String> teamABatting = parseList(lines.get(4));
        List<String> teamBBowling = parseList(lines.get(5));
        List<String> teamBBatting = parseList(lines.get(6));
        List<String> teamABowling = parseList(lines.get(7));
        String overview = lines.get(8).replace("\\n", "\n");

        Match match = new Match(teamAName, teamBName, teamABatting, teamBBowling, teamBBatting, teamABowling, overview);
        match.setTeamA(teamA);
        match.setTeamB(teamB);
        return match;
    }

    private static List<String> parseList(String line) {
        if (line.isEmpty()) return new ArrayList<>();
        String[] parts = line.split(",");
        List<String> list = new ArrayList<>();
        for (String s : parts) {
            list.add(s.trim());
        }
        return list;
    }

    private static List<Player> parsePlayers(String line) {
        List<Player> players = new ArrayList<>();
        for (String name : line.split(",")) {
            players.add(new Player(name.trim())); // assumes Player has constructor Player(String name)
        }
        return players;
    }

}
