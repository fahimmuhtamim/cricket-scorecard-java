package com.example.cricketscorer;

import java.util.ArrayList;
import java.util.List;

public class Match {
    private List<Player> teamA;
    private List<Player> teamB;
    private String teamAName;
    private String teamBName;

    public Match(String teamAName, String teamBName) {
        this.teamAName = teamAName;
        this.teamBName = teamBName;
        this.teamA = new ArrayList<>();
        this.teamB = new ArrayList<>();
    }

    public boolean addPlayerToTeamA(Player player) {
        if (teamA.size() < 11) {
            teamA.add(player);
            return true;
        }
        return false;
    }

    public boolean addPlayerToTeamB(Player player) {
        if (teamB.size() < 11) {
            teamB.add(player);
            return true;
        }
        return false;
    }

    public List<Player> getTeamA() {
        return teamA;
    }

    public List<Player> getTeamB() {
        return teamB;
    }

    public String getTeamAName() {
        return teamAName;
    }

    public String getTeamBName() {
        return teamBName;
    }

    @Override
    public String toString() {
        return "Match between " + teamAName + " and " + teamBName +
                "\nTeam A Players: " + teamA.size() +
                "\nTeam B Players: " + teamB.size();
    }
}
