package com.example.cricketscorer;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Match implements Serializable {
    private String teamAName;
    private String teamBName;
    private int overs; // New field for match overs
    private List<Player> teamA;
    private List<Player> teamB;
    private List<String> teamABatting;
    private List<String> teamBBowling;
    private List<String> teamBBatting;
    private List<String> teamABowling;
    private String overview;

    // New fields for individual batting scores
    private Map<String, Integer> teamABattingScores;
    private Map<String, Integer> teamBBattingScores;

    public Match(String teamAName, String teamBName) {
        this.teamAName = teamAName;
        this.teamBName = teamBName;
        this.overs = 20; // Default overs
        this.teamA = new ArrayList<>();
        this.teamB = new ArrayList<>();
        this.teamABatting = new ArrayList<>();
        this.teamBBowling = new ArrayList<>();
        this.teamBBatting = new ArrayList<>();
        this.teamABowling = new ArrayList<>();
        this.overview = "";
        this.teamABattingScores = new HashMap<>();
        this.teamBBattingScores = new HashMap<>();
    }

    public Match(String teamAName, String teamBName, int overs, List<String> teamABatting, List<String> teamBBowling,
                 List<String> teamBBatting, List<String> teamABowling, String overview) {
        this.teamAName = teamAName;
        this.teamBName = teamBName;
        this.overs = overs;
        this.teamABatting = teamABatting;
        this.teamBBowling = teamBBowling;
        this.teamBBatting = teamBBatting;
        this.teamABowling = teamABowling;
        this.overview = overview;
        this.teamA = new ArrayList<>();
        this.teamB = new ArrayList<>();
        this.teamABattingScores = new HashMap<>();
        this.teamBBattingScores = new HashMap<>();

        // Generate individual batting scores from bowling data
        generateBattingScores();
    }

    // Generate batting scores from bowling data
    private void generateBattingScores() {
        // Generate random scores for batting lineup (you can modify this logic)
        for (String batter : teamABatting) {
            teamABattingScores.put(batter, (int)(Math.random() * 50)); // Random score 0-49
        }
        for (String batter : teamBBatting) {
            teamBBattingScores.put(batter, (int)(Math.random() * 50)); // Random score 0-49
        }
    }

    // Calculate team total score from bowling figures
    public TeamScore getTeamAScore() {
        return calculateTeamScore(teamBBowling);
    }

    public TeamScore getTeamBScore() {
        return calculateTeamScore(teamABowling);
    }

    private TeamScore calculateTeamScore(List<String> bowlingData) {
        int totalRuns = 0;
        int totalWickets = 0;

        for (String bowlerStats : bowlingData) {
            if (bowlerStats.contains(":")) {
                String[] parts = bowlerStats.split(":", 2);
                String ballSequence = parts[1].trim();

                CricketDataParser.BowlingFigures figures =
                        CricketDataParser.calculateBowlingFigures(ballSequence);

                totalRuns += figures.runs;
                totalWickets += figures.wickets;
            }
        }

        return new TeamScore(totalRuns, totalWickets);
    }

    // Determine match result
    public String getMatchResult() {
        TeamScore teamAScore = getTeamAScore();
        TeamScore teamBScore = getTeamBScore();

        if (teamAScore.runs > teamBScore.runs) {
            int margin = teamAScore.runs - teamBScore.runs;
            return teamAName + " won by " + margin + " runs";
        } else if (teamBScore.runs > teamAScore.runs) {
            int margin = teamBScore.runs - teamAScore.runs;
            return teamBName + " won by " + margin + " runs";
        } else {
            return "Match Tied";
        }
    }

    // Inner class for team score
    public static class TeamScore {
        public final int runs;
        public final int wickets;

        public TeamScore(int runs, int wickets) {
            this.runs = runs;
            this.wickets = wickets;
        }

        @Override
        public String toString() {
            return runs + "-" + wickets;
        }
    }

    // Getters and setters
    public String getTeamAName() {
        return teamAName;
    }

    public String getTeamBName() {
        return teamBName;
    }

    public int getOvers() {
        return overs;
    }

    public void setOvers(int overs) {
        this.overs = overs;
    }

    public List<Player> getTeamA() {
        return teamA;
    }

    public List<Player> getTeamB() {
        return teamB;
    }

    public void setTeamA(List<Player> teamA) {
        this.teamA = teamA;
    }

    public void setTeamB(List<Player> teamB) {
        this.teamB = teamB;
    }

    public List<String> getBattingA() {
        return teamABatting;
    }

    public List<String> getBattingB() {
        return teamBBatting;
    }

    public List<String> getBowlingA() {
        return teamABowling;
    }

    public List<String> getBowlingB() {
        return teamBBowling;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public Map<String, Integer> getTeamABattingScores() {
        return teamABattingScores;
    }

    public Map<String, Integer> getTeamBBattingScores() {
        return teamBBattingScores;
    }

    public void setTeamABattingScores(Map<String, Integer> scores) {
        this.teamABattingScores = scores;
    }

    public void setTeamBBattingScores(Map<String, Integer> scores) {
        this.teamBBattingScores = scores;
    }

    @Override
    public String toString() {
        return teamAName + " vs " + teamBName + " (" + overs + " overs)";
    }

    // Convert the match to a list of strings for writing to file
    public List<String> toFileString() {
        List<String> lines = new ArrayList<>();
        lines.add(teamAName);
        lines.add(teamBName);
        lines.add("Overs: " + overs); // Add overs line

        lines.add(String.join(",", playerNames(teamA)));
        lines.add(String.join(",", playerNames(teamB)));

        lines.add(String.join(",", teamABatting));
        lines.add(String.join(",", teamBBowling));
        lines.add(String.join(",", teamBBatting));
        lines.add(String.join(",", teamABowling));
        lines.add(overview.replace("\n", "\\n")); // Escape newlines
        lines.add("---"); // Separator
        return lines;
    }

    private List<String> playerNames(List<Player> players) {
        List<String> names = new ArrayList<>();
        for (Player p : players) {
            names.add(p.getName()); // assumes Player has getName()
        }
        return names;
    }

    // Load a match from a list of lines
    public static Match fromFileLines(List<String> lines) {
        String teamAName = lines.get(0);
        String teamBName = lines.get(1);

        // Parse overs from line 2
        int overs = 20; // Default value
        String oversLine = lines.get(2);
        if (oversLine.startsWith("Overs: ")) {
            try {
                overs = Integer.parseInt(oversLine.substring(7).trim());
            } catch (NumberFormatException e) {
                // Keep default value if parsing fails
            }
        }

        List<Player> teamA = parsePlayers(lines.get(3));
        List<Player> teamB = parsePlayers(lines.get(4));

        List<String> teamABatting = parseList(lines.get(5));
        List<String> teamBBowling = parseList(lines.get(6));
        List<String> teamBBatting = parseList(lines.get(7));
        List<String> teamABowling = parseList(lines.get(8));
        String overview = lines.get(9).replace("\\n", "\n");

        Match match = new Match(teamAName, teamBName, overs, teamABatting, teamBBowling, teamBBatting, teamABowling, overview);
        match.setTeamA(teamA);
        match.setTeamB(teamB);
        return match;
    }

    private static List<String> parseList(String line) {
        if (line.isEmpty()) return new ArrayList<>();
        String[] parts = line.split(",");
        List<String> list = new ArrayList<>();
        for (String s : parts) {
            list.add(s.trim());
        }
        return list;
    }

    private static List<Player> parsePlayers(String line) {
        List<Player> players = new ArrayList<>();
        for (String name : line.split(",")) {
            players.add(new Player(name.trim())); // assumes Player has constructor Player(String name)
        }
        return players;
    }
}