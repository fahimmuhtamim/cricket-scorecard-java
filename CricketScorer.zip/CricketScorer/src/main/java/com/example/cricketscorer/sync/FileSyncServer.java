package com.example.cricketscorer.sync;

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

public class FileSyncServer {
    private static final int PORT = 8888;
    private ServerSocket serverSocket;
    private final Set<ClientHandler> clients = ConcurrentHashMap.newKeySet();
    private final ExecutorService executor = Executors.newCachedThreadPool();
    private volatile boolean running = true;
    private WatchService watchService;
    private final String syncDirectory;
    private Map<String, Long> fileLastModified = new ConcurrentHashMap<>();

    public FileSyncServer(String syncDirectory) {
        this.syncDirectory = syncDirectory;
    }

    public void start() throws IOException {
        serverSocket = new ServerSocket(PORT);
        System.out.println("Cricket Scorer Sync Server started on port " + PORT);
        System.out.println("Monitoring directory: " + syncDirectory);

        // Start file watcher
        startFileWatcher();

        // Accept client connections
        while (running) {
            try {
                Socket clientSocket = serverSocket.accept();
                ClientHandler client = new ClientHandler(clientSocket, this);
                clients.add(client);
                executor.submit(client);
                System.out.println("Client connected: " + clientSocket.getInetAddress());

                // Send existing tournaments list to new client
                sendExistingDataToClient(client);

            } catch (IOException e) {
                if (running) {
                    System.err.println("Error accepting client connection: " + e.getMessage());
                }
            }
        }
    }

    private void sendExistingDataToClient(ClientHandler client) {
        executor.submit(() -> {
            try {
                // Send tournaments.txt first
                sendFileToClient(client, "tournaments.txt");

                // Send all tournament files
                File dir = new File(syncDirectory);
                if (dir.exists()) {
                    File[] files = dir.listFiles((d, name) -> name.endsWith(".txt") && !name.equals("tournaments.txt"));
                    if (files != null) {
                        for (File file : files) {
                            sendFileToClient(client, file.getName());
                        }
                    }
                }
            } catch (Exception e) {
                System.err.println("Error sending existing data to client: " + e.getMessage());
            }
        });
    }

    private void sendFileToClient(ClientHandler client, String filename) {
        try {
            String content = readFileContent(filename);
            if (content != null) {
                FileMessage message = new FileMessage(FileMessage.MessageType.FILE_CONTENT, filename, content);
                client.sendMessage(message);
                Thread.sleep(100); // Small delay to prevent overwhelming client
            }
        } catch (Exception e) {
            System.err.println("Error sending file " + filename + " to client: " + e.getMessage());
        }
    }

    private void startFileWatcher() {
        executor.submit(() -> {
            try {
                watchService = FileSystems.getDefault().newWatchService();
                Path path = Paths.get(syncDirectory);

                // Create directory if it doesn't exist
                if (!Files.exists(path)) {
                    Files.createDirectories(path);
                }

                path.register(watchService,
                        StandardWatchEventKinds.ENTRY_CREATE,
                        StandardWatchEventKinds.ENTRY_MODIFY,
                        StandardWatchEventKinds.ENTRY_DELETE);

                while (running) {
                    WatchKey key = watchService.take();

                    for (WatchEvent<?> event : key.pollEvents()) {
                        WatchEvent.Kind<?> kind = event.kind();
                        String filename = event.context().toString();

                        // Sync all .txt files (tournaments and match data)
                        if (filename.endsWith(".txt")) {
                            // Check if file was actually modified (prevents duplicate events)
                            if (shouldProcessFileChange(filename)) {
                                handleFileChange(kind, filename);
                            }
                        }
                    }

                    key.reset();
                }
            } catch (IOException | InterruptedException e) {
                if (running) {
                    System.err.println("File watcher error: " + e.getMessage());
                }
            }
        });
    }

    private boolean shouldProcessFileChange(String filename) {
        try {
            Path filePath = Paths.get(syncDirectory, filename);
            if (!Files.exists(filePath)) {
                // File was deleted
                fileLastModified.remove(filename);
                return true;
            }

            long currentModified = Files.getLastModifiedTime(filePath).toMillis();
            Long lastModified = fileLastModified.get(filename);

            if (lastModified == null || currentModified > lastModified + 1000) { // 1 second threshold
                fileLastModified.put(filename, currentModified);
                return true;
            }

            return false;
        } catch (IOException e) {
            return true; // Process on error to be safe
        }
    }

    private void handleFileChange(WatchEvent.Kind<?> kind, String filename) {
        try {
            FileMessage.MessageType messageType;
            String content = null;

            if (kind == StandardWatchEventKinds.ENTRY_CREATE) {
                messageType = FileMessage.MessageType.FILE_CREATED;
                content = readFileContent(filename);
                System.out.println("New file created: " + filename);
            } else if (kind == StandardWatchEventKinds.ENTRY_MODIFY) {
                messageType = FileMessage.MessageType.FILE_UPDATED;
                content = readFileContent(filename);
                System.out.println("File updated: " + filename);
            } else if (kind == StandardWatchEventKinds.ENTRY_DELETE) {
                messageType = FileMessage.MessageType.FILE_DELETED;
                System.out.println("File deleted: " + filename);
            } else {
                return;
            }

            FileMessage message = new FileMessage(messageType, filename, content);
            broadcastToClients(message);

        } catch (IOException e) {
            System.err.println("Error handling file change for " + filename + ": " + e.getMessage());
        }
    }

    public String readFileContent(String filename) throws IOException {
        Path filePath = Paths.get(syncDirectory, filename);
        if (Files.exists(filePath)) {
            return new String(Files.readAllBytes(filePath));
        }
        return null;
    }

    public void broadcastToClients(FileMessage message) {
        Iterator<ClientHandler> iterator = clients.iterator();
        int successCount = 0;
        int failCount = 0;

        while (iterator.hasNext()) {
            ClientHandler client = iterator.next();
            if (client.sendMessage(message)) {
                successCount++;
            } else {
                iterator.remove(); // Remove disconnected clients
                failCount++;
            }
        }

        if (successCount > 0 || failCount > 0) {
            System.out.println("Broadcasted " + message.getFilename() + " to " + successCount +
                    " clients (" + failCount + " failed)");
        }
    }

    public void removeClient(ClientHandler client) {
        clients.remove(client);
        System.out.println("Client removed. Active clients: " + clients.size());
    }

    public void stop() {
        running = false;
        executor.shutdown();
        try {
            if (serverSocket != null) {
                serverSocket.close();
            }
            if (watchService != null) {
                watchService.close();
            }
        } catch (IOException e) {
            System.err.println("Error stopping server: " + e.getMessage());
        }
    }

    // Method to manually trigger file sync (useful for testing)
    public void triggerFileSync(String filename) {
        try {
            String content = readFileContent(filename);
            FileMessage message = new FileMessage(FileMessage.MessageType.FILE_UPDATED, filename, content);
            broadcastToClients(message);
        } catch (IOException e) {
            System.err.println("Error manually syncing file " + filename + ": " + e.getMessage());
        }
    }

    // Get server status
    public int getConnectedClientsCount() {
        return clients.size();
    }

    public boolean isRunning() {
        return running;
    }

    public static void main(String[] args) {
        String syncDir = args.length > 0 ? args[0] : "./cricket_data";
        FileSyncServer server = new FileSyncServer(syncDir);

        // Add shutdown hook
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("Shutting down server...");
            server.stop();
        }));

        try {
            server.start();
        } catch (IOException e) {
            System.err.println("Failed to start server: " + e.getMessage());
        }
    }
}