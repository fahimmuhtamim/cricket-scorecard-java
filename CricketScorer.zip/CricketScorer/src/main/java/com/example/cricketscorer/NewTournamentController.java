package com.example.cricketscorer;

import com.example.cricketscorer.sync.SyncIntegrationManager;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.*;
import java.util.List;

public class NewTournamentController {
    @FXML private TextField tournamentNameField;
    @FXML private TextField team1Field, team2Field, team3Field, team4Field;
    @FXML private TextField team5Field, team6Field, team7Field;
    @FXML private Button backButton;
    @FXML private Button submitButton;

    private final String INDEX_FILE = "tournaments.txt";
    private SyncIntegrationManager syncManager;

    @FXML
    private void initialize() {
        syncManager = SyncIntegrationManager.getInstance();
    }

    @FXML
    private void handleSubmit() {
        String name = tournamentNameField.getText().trim();
        if (name.isEmpty()) {
            showErrorAlert("Tournament name is required.");
            return;
        }

        // Disable submit button to prevent double submission
        submitButton.setDisable(true);

        Tournament tournament = new Tournament(name);

        for (TextField tf : List.of(team1Field, team2Field, team3Field, team4Field,
                team5Field, team6Field, team7Field)) {
            String teamName = tf.getText().trim();
            if (!teamName.isEmpty()) {
                tournament.createEmptyTeam(teamName);
            }
        }

        try {
            String filename = name.replaceAll("\\s+", "") + ".txt";

            // Save tournament file
            tournament.saveToFile(filename);

            // Update tournaments index
            try (PrintWriter out = new PrintWriter(new FileWriter(INDEX_FILE, true))) {
                out.println(filename);
            }

            System.out.println("Tournament saved to " + filename);

            // Notify sync manager about new tournament
            syncManager.notifyNewTournament(filename);

            showSuccessAlert("Tournament '" + name + "' created successfully!\n" +
                    "All connected users will be notified of the new tournament.");

            clearForm();

            // Re-enable submit button
            submitButton.setDisable(false);

        } catch (IOException e) {
            System.err.println("Error saving tournament: " + e.getMessage());
            e.printStackTrace();
            showErrorAlert("Error saving tournament: " + e.getMessage());
            submitButton.setDisable(false);
        }
    }

    private void clearForm() {
        tournamentNameField.clear();
        team1Field.clear();
        team2Field.clear();
        team3Field.clear();
        team4Field.clear();
        team5Field.clear();
        team6Field.clear();
        team7Field.clear();
    }

    public void goBack(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("tournament-list.fxml"));
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }

    private void showSuccessAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}