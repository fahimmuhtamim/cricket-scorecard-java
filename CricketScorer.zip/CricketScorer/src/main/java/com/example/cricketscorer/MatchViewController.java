package com.example.cricketscorer;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;

public class MatchViewController {

    @FXML private Label team1Label;
    @FXML private Label team2Label;
    @FXML private Label team1ScoreLabel;
    @FXML private Label team2ScoreLabel;

    @FXML private VBox team1BattingVBox;  // Changed to VBox for multiple batters
    @FXML private VBox team2BowlingVBox;  // Changed to VBox for multiple bowlers
    @FXML private VBox team2BattingVBox;  // Changed to VBox for multiple batters
    @FXML private VBox team1BowlingVBox;  // Changed to VBox for multiple bowlers

    @FXML private ScrollPane overviewScroll;
    @FXML private Label overviewLabel;

    public void setMatch(Match match) {
        team1Label.setText(match.getTeamAName());
        team2Label.setText(match.getTeamBName());

        // Display Team A batting lineup (who batted)
        displayBattingLineup(team1BattingVBox, match.getBattingA(), match.getTeamAName() + " Batting Lineup");
        team1ScoreLabel.setText("Batting First");

        // Display Team B bowling against Team A
        displayBowlingStats(team2BowlingVBox, match.getBowlingB(), match.getTeamBName() + " Bowling");

        // Display Team B batting lineup (who batted)
        displayBattingLineup(team2BattingVBox, match.getBattingB(), match.getTeamBName() + " Batting Lineup");
        team2ScoreLabel.setText("Batting Second");

        // Display Team A bowling against Team B
        displayBowlingStats(team1BowlingVBox, match.getBowlingA(), match.getTeamAName() + " Bowling");

        // Show overview with better formatting
        overviewLabel.setText(formatOverview(match.getOverview()));
    }

    private void displayBattingLineup(VBox container, java.util.List<String> battingLineup, String title) {
        container.getChildren().clear();

        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px; -fx-text-fill: #2E8B57;");
        container.getChildren().add(titleLabel);

        if (battingLineup.isEmpty()) {
            container.getChildren().add(new Label("No batting lineup available"));
            return;
        }

        // Display batting lineup players
        for (String player : battingLineup) {
            if (player == null || player.trim().isEmpty()) continue;

            Label playerLabel = new Label("• " + player);
            playerLabel.setStyle("-fx-padding: 2px 0px; -fx-font-size: 12px;");
            container.getChildren().add(playerLabel);
        }
    }

    private void displayBowlingStats(VBox container, java.util.List<String> bowlingData, String title) {
        container.getChildren().clear();

        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");
        container.getChildren().add(titleLabel);

        if (bowlingData.isEmpty()) {
            container.getChildren().add(new Label("No bowling data available"));
            return;
        }

        // Parse and display bowling statistics
        for (String playerStats : bowlingData) {
            if (playerStats == null || playerStats.trim().isEmpty()) continue;

            Label playerLabel = new Label(formatBowlingDisplay(playerStats));
            playerLabel.setStyle("-fx-padding: 2px 0px;");
            container.getChildren().add(playerLabel);
        }
    }

    private String formatBattingStats(String rawStats) {
        // Assuming format like "PlayerName runs(balls) SR: strikeRate"
        // You may need to adjust this based on your actual data format
        if (rawStats.contains("(") && rawStats.contains(")")) {
            return rawStats; // Already formatted
        }

        // If it's just a player name or basic format, return as is for now
        return rawStats;
    }

    private String formatBowlingDisplay(String bowlerStats) {
        // Format: "BowlerName: ball stats"
        // Example: "Shaheen: 1 0 4 0 2 1"
        if (bowlerStats.contains(":")) {
            String[] parts = bowlerStats.split(":", 2);
            String bowlerName = parts[0].trim();
            String balls = parts[1].trim();

            // Count and format the bowling figures
            String[] ballArray = balls.split("\\s+");
            int runs = 0, wickets = 0, balls_bowled = 0;

            for (String ball : ballArray) {
                if (ball.equals("wk")) {
                    wickets++;
                    balls_bowled++;
                } else if (ball.startsWith("b+")) {
                    // bye, count as ball but no run to bowler
                    balls_bowled++;
                } else if (ball.equals("wd")) {
                    // wide, add 1 run but no ball
                    runs++;
                } else if (ball.matches("\\d+")) {
                    // regular runs
                    runs += Integer.parseInt(ball);
                    balls_bowled++;
                } else if (ball.contains("+")) {
                    // extras with runs
                    String[] extraParts = ball.split("\\+");
                    if (extraParts.length == 2 && extraParts[1].matches("\\d+")) {
                        runs += Integer.parseInt(extraParts[1]);
                        if (!extraParts[0].equals("wd")) balls_bowled++;
                    }
                }
            }

            double overs = balls_bowled / 6.0 + (balls_bowled % 6) * 0.1;
            double economy = balls_bowled > 0 ? (runs * 6.0) / balls_bowled : 0.0;

            return String.format("%s: %.1f-%d-%d (Econ: %.2f)",
                    bowlerName, overs, runs, wickets, economy);
        }

        return bowlerStats; // Return as-is if format is unexpected
    }

    private String getTeamScore(java.util.List<String> battingData) {
        if (battingData.isEmpty()) return "0/0 (0.0 overs)";

        // Extract total runs and wickets from batting data
        // This depends on how you store the team total
        // For now, return first entry or calculate from individual scores
        return battingData.get(0); // Assuming first entry is team total
    }

    private String formatOverview(String overview) {
        if (overview == null || overview.trim().isEmpty()) {
            return "No match commentary available.";
        }

        // The overview is already formatted from the bowling stats
        return overview;
    }
}