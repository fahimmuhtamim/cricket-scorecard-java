package com.example.cricketscorer;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;

public class MatchViewController {

    @FXML private Label team1Label;
    @FXML private Label team2Label;
    @FXML private Label team1TotalScore; // NEW - Team total scores
    @FXML private Label team2TotalScore; // NEW - Team total scores
    @FXML private Label matchResultLabel; // NEW - Match result

    @FXML private VBox team1BattingVBox;
    @FXML private VBox team2BowlingVBox;
    @FXML private VBox team2BattingVBox;
    @FXML private VBox team1BowlingVBox;

    @FXML private ScrollPane overviewScroll;
    @FXML private Label overviewLabel;

    public void setMatch(Match match) {
        team1Label.setText(match.getTeamAName());
        team2Label.setText(match.getTeamBName());

        // Display team total scores
        Match.TeamScore teamAScore = match.getTeamAScore();
        Match.TeamScore teamBScore = match.getTeamBScore();

        team1TotalScore.setText(teamAScore.toString());
        team2TotalScore.setText(teamBScore.toString());

        // Display match result
        matchResultLabel.setText(match.getMatchResult());

        // Display Team A batting lineup with individual scores
        displayBattingLineupWithScores(team1BattingVBox, match.getBattingA(),
                match.getTeamABattingScores(),
                match.getTeamAName() + " Batting Lineup");

        // Display Team B bowling against Team A
        displayBowlingStats(team2BowlingVBox, match.getBowlingB(), match.getTeamBName() + " Bowling");

        // Display Team B batting lineup with individual scores
        displayBattingLineupWithScores(team2BattingVBox, match.getBattingB(),
                match.getTeamBBattingScores(),
                match.getTeamBName() + " Batting Lineup");

        // Display Team A bowling against Team B
        displayBowlingStats(team1BowlingVBox, match.getBowlingA(), match.getTeamAName() + " Bowling");

        // Show overview with better formatting
        overviewLabel.setText(formatOverview(match.getOverview()));
    }

    private void displayBattingLineupWithScores(VBox container, java.util.List<String> battingLineup,
                                                java.util.Map<String, Integer> battingScores, String title) {
        container.getChildren().clear();

        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px; -fx-text-fill: #2E8B57;");
        container.getChildren().add(titleLabel);

        if (battingLineup.isEmpty()) {
            container.getChildren().add(new Label("No batting lineup available"));
            return;
        }

        // Display batting lineup players with their scores
        for (String player : battingLineup) {
            if (player == null || player.trim().isEmpty()) continue;

            // Get individual score for this player
            Integer playerScore = battingScores.getOrDefault(player, 0);
            String displayText = "• " + player + " - " + playerScore;

            Label playerLabel = new Label(displayText);
            playerLabel.setStyle("-fx-padding: 2px 0px; -fx-font-size: 12px;");
            container.getChildren().add(playerLabel);
        }
    }

    private void displayBowlingStats(VBox container, java.util.List<String> bowlingData, String title) {
        container.getChildren().clear();

        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");
        container.getChildren().add(titleLabel);

        if (bowlingData.isEmpty()) {
            container.getChildren().add(new Label("No bowling data available"));
            return;
        }

        // Parse and display bowling statistics
        for (String playerStats : bowlingData) {
            if (playerStats == null || playerStats.trim().isEmpty()) continue;

            Label playerLabel = new Label(formatBowlingDisplay(playerStats));
            playerLabel.setStyle("-fx-padding: 2px 0px; -fx-font-size: 12px;");
            container.getChildren().add(playerLabel);
        }
    }

    private String formatBowlingDisplay(String bowlerStats) {
        // Format: "BowlerName: ball stats"
        // Example: "Shaheen: 1 0 4 0 2 1"
        if (bowlerStats.contains(":")) {
            String[] parts = bowlerStats.split(":", 2);
            String bowlerName = parts[0].trim();
            String balls = parts[1].trim();

            // Use the CricketDataParser to calculate figures
            CricketDataParser.BowlingFigures figures =
                    CricketDataParser.calculateBowlingFigures(balls);

            return String.format("%s: %s-%d-%d (Econ: %.2f)",
                    bowlerName,
                    figures.getOverString(),
                    figures.runs,
                    figures.wickets,
                    figures.getEconomy());
        }

        return bowlerStats; // Return as-is if format is unexpected
    }

    private String formatOverview(String overview) {
        if (overview == null || overview.trim().isEmpty()) {
            return "No match commentary available.";
        }

        // The overview is already formatted from the bowling stats
        return overview;
    }
}