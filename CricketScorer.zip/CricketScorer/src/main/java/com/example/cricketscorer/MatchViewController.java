package com.example.cricketscorer;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;
import java.util.*;
import java.util.stream.Collectors;

public class MatchViewController {

    @FXML private Label team1Label;
    @FXML private Label team2Label;
    @FXML private Label team1TotalScore;
    @FXML private Label team2TotalScore;
    @FXML private Label team1OversLabel; // Add this to FXML
    @FXML private Label team2OversLabel; // Add this to FXML
    @FXML private Label matchResultLabel;

    @FXML private VBox team1BattingVBox;
    @FXML private VBox team2BowlingVBox;
    @FXML private VBox team2BattingVBox;
    @FXML private VBox team1BowlingVBox;

    @FXML private ScrollPane overviewScroll;
    @FXML private Label overviewLabel;

    public void setMatch(Match match) {
        team1Label.setText(match.getTeamAName());
        team2Label.setText(match.getTeamBName());

        // Display team total scores
        Match.TeamScore teamAScore = match.getTeamAScore();
        Match.TeamScore teamBScore = match.getTeamBScore();

        team1TotalScore.setText(teamAScore.toString());
        team2TotalScore.setText(teamBScore.toString());

        // Display overs completed for each team
        double team1Overs = calculateOversCompleted(match.getBowlingB()); // Team B bowling to Team A
        double team2Overs = calculateOversCompleted(match.getBowlingA()); // Team A bowling to Team B

        if (team1OversLabel != null) {
            team1OversLabel.setText(formatOvers(team1Overs) + "/" + match.getOvers());
        }
        if (team2OversLabel != null) {
            team2OversLabel.setText(formatOvers(team2Overs) + "/" + match.getOvers());
        }

        // Display match result only if match is finished
        String matchResult = match.getMatchResult();
        matchResultLabel.setText(matchResult);

        // Style the result label differently if match is in progress
        if (match.finished()) {
            matchResultLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px; -fx-text-fill: #2E8B57;");

            // Show best 3 batters and bowlers for finished match
            displayBest3Batters(team1BattingVBox, match.getTeamABattingScores(),
                    match.getTeamAName());
            displayBest3Batters(team2BattingVBox, match.getTeamBBattingScores(),
                    match.getTeamBName());
            displayBest3Bowlers(team2BowlingVBox, match.getBowlingB(),
                    match.getTeamBName());
            displayBest3Bowlers(team1BowlingVBox, match.getBowlingA(),
                    match.getTeamAName());
        } else {
            matchResultLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px; -fx-text-fill: #FF6347;");
            matchResultLabel.setText("Match in Progress");

            // Show current batters and bowlers for ongoing match
            displayCurrentBatters(team1BattingVBox, match.getBattingA(), match.getTeamABattingScores(),
                    match.getBowlingB(), match.getTeamAName() + " - Current Batters");
            displayCurrentBatters(team2BattingVBox, match.getBattingB(), match.getTeamBBattingScores(),
                    match.getBowlingA(), match.getTeamBName() + " - Current Batters");
            displayCurrentBowler(team2BowlingVBox, match.getBowlingB(),
                    match.getTeamBName() + " - Current Bowler");
            displayCurrentBowler(team1BowlingVBox, match.getBowlingA(),
                    match.getTeamAName() + " - Current Bowler");
        }

        // Show overview with better formatting
        overviewLabel.setText(formatOverview(match.getOverview()));
    }

    // Calculate overs completed from bowling data
    private double calculateOversCompleted(List<String> bowlingData) {
        int totalBalls = 0;

        for (String bowlerStats : bowlingData) {
            if (bowlerStats != null && bowlerStats.contains(":")) {
                String[] parts = bowlerStats.split(":", 2);
                if (parts.length >= 2) {
                    String ballSequence = parts[1].trim();

                    if (!ballSequence.isEmpty()) {
                        CricketDataParser.BowlingFigures figures =
                                CricketDataParser.calculateBowlingFigures(ballSequence);
                        totalBalls += figures.balls;
                    }
                }
            }
        }

        // Convert total balls to overs (6 balls = 1 over)
        return totalBalls / 6.0;
    }

    // Format overs for display (e.g., 20.3 becomes "20.3")
    private String formatOvers(double overs) {
        int completeOvers = (int) overs;
        int remainingBalls = (int) Math.round((overs - completeOvers) * 6);

        // Handle rounding edge case where remainingBalls becomes 6
        if (remainingBalls >= 6) {
            completeOvers += remainingBalls / 6;
            remainingBalls = remainingBalls % 6;
        }

        if (remainingBalls == 0) {
            return String.valueOf(completeOvers);
        } else {
            return completeOvers + "." + remainingBalls;
        }
    }

    private void displayBest3Batters(VBox container, Map<String, Integer> battingScores, String title) {
        container.getChildren().clear();

        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px; -fx-text-fill: #2E8B57;");
        container.getChildren().add(titleLabel);

        if (battingScores.isEmpty()) {
            container.getChildren().add(new Label("No batting data available"));
            return;
        }

        // Sort batters by runs scored (descending), then by name (lexicographic) and get top 3
        List<Map.Entry<String, Integer>> sortedBatters = battingScores.entrySet().stream()
                .sorted((a, b) -> {
                    // First compare by runs (higher runs first)
                    int runsComparison = Integer.compare(b.getValue(), a.getValue());
                    if (runsComparison != 0) {
                        return runsComparison;
                    }
                    // If runs are same, compare by name (lexicographic order)
                    return a.getKey().compareTo(b.getKey());
                })
                .limit(3)
                .collect(Collectors.toList());

        int rank = 1;
        for (Map.Entry<String, Integer> entry : sortedBatters) {
            String displayText = rank + ". " + entry.getKey() + " - " + entry.getValue() + " runs";
            Label playerLabel = new Label(displayText);
            playerLabel.setStyle("-fx-padding: 2px 0px; -fx-font-size: 12px;");
            container.getChildren().add(playerLabel);
            rank++;
        }
    }

    private void displayBest3Bowlers(VBox container, List<String> bowlingData, String title) {
        container.getChildren().clear();

        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");
        container.getChildren().add(titleLabel);

        if (bowlingData.isEmpty()) {
            container.getChildren().add(new Label("No bowling data available"));
            return;
        }

        // Calculate bowling figures for all bowlers
        List<BowlerPerformance> bowlerPerformances = new ArrayList<>();
        for (String bowlerStats : bowlingData) {
            if (bowlerStats == null || !bowlerStats.contains(":")) continue;

            String[] parts = bowlerStats.split(":", 2);
            String bowlerName = parts[0].trim();
            String ballSequence = parts[1].trim();

            CricketDataParser.BowlingFigures figures =
                    CricketDataParser.calculateBowlingFigures(ballSequence);

            bowlerPerformances.add(new BowlerPerformance(bowlerName, figures));
        }

        // Sort bowlers by wickets (descending), then by runs conceded (ascending), then by name (lexicographic)
        bowlerPerformances.sort((a, b) -> {
            // First compare by wickets (more wickets first)
            if (a.figures.wickets != b.figures.wickets) {
                return Integer.compare(b.figures.wickets, a.figures.wickets);
            }
            // If wickets are same, compare by runs conceded (fewer runs first)
            if (a.figures.bowlerRuns != b.figures.bowlerRuns) {
                return Integer.compare(a.figures.bowlerRuns, b.figures.bowlerRuns);
            }
            // If both wickets and runs are same, compare by name (lexicographic order)
            return a.name.compareTo(b.name);
        });

        // Display top 3 bowlers
        int rank = 1;
        for (int i = 0; i < Math.min(3, bowlerPerformances.size()); i++) {
            BowlerPerformance bp = bowlerPerformances.get(i);
            String displayText = String.format("%d. %s - %s-%d-%d (Econ: %.2f)",
                    rank, bp.name, bp.figures.getOverString(), bp.figures.bowlerRuns,
                    bp.figures.wickets, bp.figures.getEconomy());

            Label bowlerLabel = new Label(displayText);
            bowlerLabel.setStyle("-fx-padding: 2px 0px; -fx-font-size: 12px;");
            container.getChildren().add(bowlerLabel);
            rank++;
        }
    }

    private void displayCurrentBatters(VBox container, List<String> battingLineup,
                                       Map<String, Integer> battingScores, List<String> bowlingData, String title) {
        container.getChildren().clear();

        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px; -fx-text-fill: #FF6347;");
        container.getChildren().add(titleLabel);

        if (battingLineup.isEmpty()) {
            container.getChildren().add(new Label("No batting data available"));
            return;
        }

        // Find current batters by analyzing bowling data
        List<String> currentBatters = getCurrentBatters(battingLineup, bowlingData);

        if (currentBatters.isEmpty()) {
            // If no current batters found, show first 2 from lineup
            currentBatters = battingLineup.subList(0, Math.min(2, battingLineup.size()));
        }

        // Limit to exactly 2 current batters
        int battersToShow = Math.min(2, currentBatters.size());
        for (int i = 0; i < battersToShow; i++) {
            String batter = currentBatters.get(i);
            Integer score = battingScores.getOrDefault(batter, 0);
            String displayText = "• " + batter + " - " + score + " runs*";
            Label batterLabel = new Label(displayText);
            batterLabel.setStyle("-fx-padding: 2px 0px; -fx-font-size: 12px; -fx-text-fill: #FF6347;");
            container.getChildren().add(batterLabel);
        }

        if (battersToShow > 0) {
            Label noteLabel = new Label("*Currently batting");
            noteLabel.setStyle("-fx-padding: 2px 0px; -fx-font-size: 10px; -fx-font-style: italic;");
            container.getChildren().add(noteLabel);
        }
    }

    private void displayCurrentBowler(VBox container, List<String> bowlingData, String title) {
        container.getChildren().clear();

        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px; -fx-text-fill: #FF6347;");
        container.getChildren().add(titleLabel);

        if (bowlingData.isEmpty()) {
            container.getChildren().add(new Label("No bowling data available"));
            return;
        }

        // Get the last bowler (current bowler)
        String currentBowlerStats = bowlingData.get(bowlingData.size() - 1);
        if (currentBowlerStats != null && currentBowlerStats.contains(":")) {
            String[] parts = currentBowlerStats.split(":", 2);
            String bowlerName = parts[0].trim();
            String ballSequence = parts[1].trim();

            CricketDataParser.BowlingFigures figures =
                    CricketDataParser.calculateBowlingFigures(ballSequence);

            String displayText = String.format("• %s - %s-%d-%d (Econ: %.2f)*",
                    bowlerName, figures.getOverString(), figures.bowlerRuns,
                    figures.wickets, figures.getEconomy());

            Label bowlerLabel = new Label(displayText);
            bowlerLabel.setStyle("-fx-padding: 2px 0px; -fx-font-size: 12px; -fx-text-fill: #FF6347;");
            container.getChildren().add(bowlerLabel);

            Label noteLabel = new Label("*Currently bowling");
            noteLabel.setStyle("-fx-padding: 2px 0px; -fx-font-size: 10px; -fx-font-style: italic;");
            container.getChildren().add(noteLabel);
        }
    }

    private List<String> getCurrentBatters(List<String> battingLineup, List<String> bowlingData) {
        List<String> currentBatters = new ArrayList<>();

        if (battingLineup.isEmpty() || bowlingData.isEmpty()) {
            return currentBatters;
        }

        int currentBatsmanIndex = 0;
        int wicketsTaken = 0;

        // Process bowling data to find current batters
        for (String bowlerStats : bowlingData) {
            if (!bowlerStats.contains(":")) continue;

            String[] parts = bowlerStats.split(":", 2);
            String ballSequence = parts[1].trim();
            String[] balls = ballSequence.split("\\s+");

            for (String ball : balls) {
                ball = ball.trim();
                if (ball.isEmpty()) continue;

                if (ball.equals("wk") || ball.contains("+wk")) {
                    wicketsTaken++;
                    currentBatsmanIndex++;
                }
            }
        }

        // Current batters are at positions: currentBatsmanIndex and currentBatsmanIndex + 1
        if (currentBatsmanIndex < battingLineup.size()) {
            currentBatters.add(battingLineup.get(currentBatsmanIndex));
        }
        if (currentBatsmanIndex + 1 < battingLineup.size()) {
            currentBatters.add(battingLineup.get(currentBatsmanIndex + 1));
        }

        return currentBatters;
    }

    private String formatOverview(String overview) {
        if (overview == null || overview.trim().isEmpty()) {
            return "No match commentary available.";
        }
        return overview;
    }

    // Helper class for bowler performance
    private static class BowlerPerformance {
        final String name;
        final CricketDataParser.BowlingFigures figures;

        BowlerPerformance(String name, CricketDataParser.BowlingFigures figures) {
            this.name = name;
            this.figures = figures;
        }
    }
}