package com.example.cricketscorer;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.AccessibleAction;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;

public class TournamentViewController {

    @FXML
    private VBox matchListVBox;
    @FXML
    private Button backButton;

    private Tournament tournament;

    public void setTournament(Tournament tournament) {
        this.tournament = tournament;
        showMatches();
    }

    private void showMatches() {
        matchListVBox.getChildren().clear();
        //System.out.println("Matches found: " + tournament.getMatches().size());
        for (Match match : tournament.getMatches()) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("match-card.fxml"));
                Node card = loader.load();
                MatchCardController controller = loader.getController();
                controller.setMatch(match);
                matchListVBox.getChildren().add(card);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    public void goBack(ActionEvent e) throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("tournament-list.fxml"));
        Stage stage = (Stage)((Node)e.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void Newmatch(ActionEvent e)throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("New-match.fxml"));
        Stage stage = (Stage)((Node)e.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }
}
