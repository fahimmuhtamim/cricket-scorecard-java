package com.example.cricketscorer;

import com.example.cricketscorer.sync.SyncManager;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class SignUp {
    private static SyncManager syncManager; // Static reference to sync manager

    @FXML
    private TextField username;

    @FXML
    private PasswordField password;

    @FXML
    private PasswordField confirmPassword;

    @FXML
    private Button signUpButton;

    @FXML
    private Label statusLabel;

    // Method to set sync manager reference
    public static void setSyncManager(SyncManager manager) {
        syncManager = manager;
    }

    @FXML
    public void handleSignUp() {
        String user = username.getText().trim();
        String pass = password.getText().trim();
        String confirm = confirmPassword.getText().trim();

        if (user.isEmpty() || pass.isEmpty() || confirm.isEmpty()) {
            statusLabel.setText("Please fill in all fields.");
            return;
        }

        if (!pass.equals(confirm)) {
            statusLabel.setText("Passwords do not match.");
            return;
        }

        // Check if user already exists
        if (userExists(user)) {
            statusLabel.setText("Username already exists.");
            return;
        }

        try {
            // Write to files
            try (
                    BufferedWriter userWriter = new BufferedWriter(new FileWriter("Users.txt", true));
                    BufferedWriter passWriter = new BufferedWriter(new FileWriter("Passwords.txt", true))
            ) {
                userWriter.write(user);
                userWriter.newLine();
                passWriter.write(pass);
                passWriter.newLine();
            }

            // Force sync of both files immediately
            if (syncManager != null && syncManager.isConnected()) {
                syncFiles();
                statusLabel.setStyle("-fx-text-fill: green;");
                statusLabel.setText("Sign up successful! Account synced.");
            } else {
                statusLabel.setStyle("-fx-text-fill: orange;");
                statusLabel.setText("Sign up successful! (Offline mode)");
            }

            username.clear();
            password.clear();
            confirmPassword.clear();
            signUpButton.setText("Log In");

            // Remove current action and add new one
            signUpButton.setOnAction(e -> {
                try {
                    Parent root = FXMLLoader.load(getClass().getResource("log-in.fxml"));
                    Stage stage = (Stage)((Node)e.getSource()).getScene().getWindow();
                    Scene scene = new Scene(root);
                    stage.setScene(scene);
                    stage.show();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            });

        } catch (IOException e) {
            statusLabel.setText("Error writing to file.");
            e.printStackTrace();
        }
    }

    private boolean userExists(String username) {
        try {
            Path usersFile = Path.of("Users.txt");
            if (Files.exists(usersFile)) {
                return Files.readAllLines(usersFile)
                        .stream()
                        .anyMatch(line -> line.trim().equals(username));
            }
        } catch (IOException e) {
            System.err.println("Error checking existing users: " + e.getMessage());
        }
        return false;
    }

    private void syncFiles() {
        try {
            // Read and sync Users.txt
            Path usersFile = Path.of("Users.txt");
            if (Files.exists(usersFile)) {
                String usersContent = Files.readString(usersFile);
                syncManager.getClient().notifyFileChange("Users.txt", usersContent);
            }

            // Read and sync Passwords.txt
            Path passwordsFile = Path.of("Passwords.txt");
            if (Files.exists(passwordsFile)) {
                String passwordsContent = Files.readString(passwordsFile);
                syncManager.getClient().notifyFileChange("Passwords.txt", passwordsContent);
            }

            // Add a small delay to ensure sync completes
            Thread.sleep(500);

        } catch (IOException | InterruptedException e) {
            System.err.println("Error during manual sync: " + e.getMessage());
        }
    }
}