package com.example.cricketscorer;

import com.example.cricketscorer.sync.SyncManager;
import javafx.fxml.*;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class LogIn {
    private static SyncManager syncManager; // Static reference to sync manager

    private Stage stage;
    private Scene scene;
    private Parent root;
    public static boolean viewer;

    @FXML
    private Button logIn;
    @FXML
    private Label wrongLogIn;
    @FXML
    private Button signUp;
    @FXML
    private Button viewerLogin;
    @FXML
    private TextField username;
    @FXML
    private PasswordField password;
    @FXML
    private Label syncStatus; // Add this to your FXML file

    public LogIn() {
    }

    // Method to set sync manager reference
    public static void setSyncManager(SyncManager manager) {
        syncManager = manager;
    }

    @FXML
    public void initialize() {
        // Update sync status if we have a sync status label
        if (syncStatus != null) {
            updateSyncStatus();
        }
    }

    private void updateSyncStatus() {
        if (syncManager != null && syncManager.isConnected()) {
            syncStatus.setText("● Online");
            syncStatus.setStyle("-fx-text-fill: green;");
        } else {
            syncStatus.setText("● Offline");
            syncStatus.setStyle("-fx-text-fill: red;");
        }
    }

    public void userLogin(ActionEvent event) throws IOException {
        checkLogin(event);
    }

    private void checkLogin(ActionEvent e) throws IOException {
        String inputUsername = username.getText().trim();
        String inputPassword = password.getText().trim();

        if (inputUsername.isEmpty() || inputPassword.isEmpty()) {
            wrongLogIn.setText("Please enter your login data.");
            return;
        }

        // If connected to sync server, request latest files first
        if (syncManager != null && syncManager.isConnected()) {
            wrongLogIn.setText("Checking credentials...");
            requestLatestUserData();

            // Give some time for sync to complete
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
            }
        }

        // Load usernames and passwords
        try {
            List<String> usernames = Files.readAllLines(Path.of("Users.txt"));
            List<String> passwords = Files.readAllLines(Path.of("Passwords.txt"));

            for (int i = 0; i < Math.min(usernames.size(), passwords.size()); i++) {
                if (usernames.get(i).trim().equals(inputUsername) &&
                        passwords.get(i).trim().equals(inputPassword)) {
                    viewer = false;
                    root = FXMLLoader.load(getClass().getResource("tournament-list.fxml"));
                    stage = (Stage)((Node)e.getSource()).getScene().getWindow();
                    scene = new Scene(root);
                    stage.setScene(scene);
                    stage.show();
                    return;
                }
            }

            wrongLogIn.setText("Wrong Username or Password.");

        } catch (IOException ex) {
            wrongLogIn.setText("Error reading user data. Try again.");
            System.err.println("Error reading user files: " + ex.getMessage());
        }
    }

    private void requestLatestUserData() {
        if (syncManager != null && syncManager.isConnected()) {
            // Request latest user files from server
            syncManager.getClient().requestFile("Users.txt");
            syncManager.getClient().requestFile("Passwords.txt");
        }
    }

    public void switchSignUp(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("sign-up.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void showTournaments(ActionEvent event) throws IOException {
        viewer = true;
        root = FXMLLoader.load(getClass().getResource("tournament-list.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}