package com.example.cricketscorer;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class PointTableController {

    // Team 1
    @FXML private TextField rank1Field;
    @FXML private TextField team1Field;
    @FXML private TextField matches1Field;
    @FXML private TextField points1Field;
    @FXML private TextField win1Field;

    // Team 2
    @FXML private TextField rank2Field;
    @FXML private TextField team2Field;
    @FXML private TextField matches2Field;
    @FXML private TextField points2Field;
    @FXML private TextField win2Field;

    // Team 3
    @FXML private TextField rank3Field;
    @FXML private TextField team3Field;
    @FXML private TextField matches3Field;
    @FXML private TextField points3Field;
    @FXML private TextField win3Field;

    @FXML
    private void initialize() {
        // Optional: initialize table values here
        rank1Field.setText("1");
        rank2Field.setText("2");
        rank3Field.setText("3");

        // Example: setting values for testing
        team1Field.setText("Tigers");
        matches1Field.setText("5");
        points1Field.setText("10");
        win1Field.setText("5");
    }

    // You can also add methods to update rows dynamically
    public void setTeamData(int row, String team, int matches, int points, int wins) {
        switch (row) {
            case 1:
                team1Field.setText(team);
                matches1Field.setText(String.valueOf(matches));
                points1Field.setText(String.valueOf(points));
                win1Field.setText(String.valueOf(wins));
                break;
            case 2:
                team2Field.setText(team);
                matches2Field.setText(String.valueOf(matches));
                points2Field.setText(String.valueOf(points));
                win2Field.setText(String.valueOf(wins));
                break;
            case 3:
                team3Field.setText(team);
                matches3Field.setText(String.valueOf(matches));
                points3Field.setText(String.valueOf(points));
                win3Field.setText(String.valueOf(wins));
                break;
        }
    }
}

