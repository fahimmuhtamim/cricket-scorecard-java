package com.example.cricketscorer;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class NewMatchController {

    // Team name fields
    @FXML private TextField team1NameField;
    @FXML private TextField team2NameField;

    // Team 1 player fields
    @FXML private TextField team1Player1;
    @FXML private TextField team1Player2;
    @FXML private TextField team1Player3;
    @FXML private TextField team1Player4;
    @FXML private TextField team1Player5;
    @FXML private TextField team1Player6;
    @FXML private TextField team1Player7;
    @FXML private TextField team1Player8;
    @FXML private TextField team1Player9;
    @FXML private TextField team1Player10;
    @FXML private TextField team1Player11;

    // Team 2 player fields
    @FXML private TextField team2Player1;
    @FXML private TextField team2Player2;
    @FXML private TextField team2Player3;
    @FXML private TextField team2Player4;
    @FXML private TextField team2Player5;
    @FXML private TextField team2Player6;
    @FXML private TextField team2Player7;
    @FXML private TextField team2Player8;
    @FXML private TextField team2Player9;
    @FXML private TextField team2Player10;
    @FXML private TextField team2Player11;

    // Overs field
    @FXML private TextField oversField;

    // Submit button
    @FXML private Button submitButton;

    private static final String ASIA_CUP_FILE = "AsiaCup.txt";

    @FXML
    public void initialize() {
        submitButton.setOnAction(e -> handleSubmit());
    }

    @FXML
    private void handleSubmit() {
        try {
            // Validate input
            if (!validateInput()) {
                return;
            }

            // Get team names
            String team1Name = team1NameField.getText().trim();
            String team2Name = team2NameField.getText().trim();

            // Get player lists
            List<String> team1Players = getTeam1Players();
            List<String> team2Players = getTeam2Players();

            // Get overs
            String overs = oversField.getText().trim();

            // Update AsiaCup.txt file
            updateAsiaCupFile(team1Name, team2Name, team1Players, team2Players, overs);

            // Show success message
            showSuccessAlert("Match added successfully!");

            // Clear form
            clearForm();

        } catch (Exception ex) {
            showErrorAlert("Error adding match: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private boolean validateInput() {
        // Check team names
        if (team1NameField.getText().trim().isEmpty()) {
            showErrorAlert("Please enter Team 1 name");
            return false;
        }

        if (team2NameField.getText().trim().isEmpty()) {
            showErrorAlert("Please enter Team 2 name");
            return false;
        }

        // Check if at least some players are entered for both teams
        List<String> team1Players = getTeam1Players();
        List<String> team2Players = getTeam2Players();

        if (team1Players.isEmpty()) {
            showErrorAlert("Please enter at least one player for Team 1");
            return false;
        }

        if (team2Players.isEmpty()) {
            showErrorAlert("Please enter at least one player for Team 2");
            return false;
        }

        // Validate overs field
        if (!oversField.getText().trim().isEmpty()) {
            try {
                int overs = Integer.parseInt(oversField.getText().trim());
                if (overs <= 0) {
                    showErrorAlert("Overs must be a positive number");
                    return false;
                }
            } catch (NumberFormatException e) {
                showErrorAlert("Please enter a valid number for overs");
                return false;
            }
        }

        return true;
    }

    private List<String> getTeam1Players() {
        List<String> players = new ArrayList<>();
        TextField[] team1Fields = {
                team1Player1, team1Player2, team1Player3, team1Player4, team1Player5,
                team1Player6, team1Player7, team1Player8, team1Player9, team1Player10, team1Player11
        };

        for (TextField field : team1Fields) {
            String playerName = field.getText().trim();
            if (!playerName.isEmpty()) {
                players.add(playerName);
            }
        }

        return players;
    }

    private List<String> getTeam2Players() {
        List<String> players = new ArrayList<>();
        TextField[] team2Fields = {
                team2Player1, team2Player2, team2Player3, team2Player4, team2Player5,
                team2Player6, team2Player7, team2Player8, team2Player9, team2Player10, team2Player11
        };

        for (TextField field : team2Fields) {
            String playerName = field.getText().trim();
            if (!playerName.isEmpty()) {
                players.add(playerName);
            }
        }

        return players;
    }

    private void updateAsiaCupFile(String team1Name, String team2Name,
                                   List<String> team1Players, List<String> team2Players,
                                   String overs) throws IOException {

        Path filePath = Paths.get(ASIA_CUP_FILE);
        List<String> lines = new ArrayList<>();

        // Read existing file if it exists
        if (Files.exists(filePath)) {
            lines = Files.readAllLines(filePath);
        } else {
            // Create basic structure if file doesn't exist
            lines.add("Asia Cup");
            lines.add("Date: " + java.time.LocalDate.now());
            lines.add("Teams:");
            lines.add("Matches:");
        }

        // Find the "Teams:" section and add new teams if they don't exist
        int teamsIndex = -1;
        int matchesIndex = -1;

        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).equals("Teams:")) {
                teamsIndex = i;
            } else if (lines.get(i).equals("Matches:")) {
                matchesIndex = i;
                break;
            }
        }

        // Add teams if they don't exist
        if (teamsIndex != -1 && matchesIndex != -1) {
            List<String> existingTeams = new ArrayList<>();
            for (int i = teamsIndex + 1; i < matchesIndex; i++) {
                String line = lines.get(i).trim();
                if (!line.isEmpty()) {
                    existingTeams.add(line);
                }
            }

            // Add team1 if not exists
            if (!existingTeams.contains(team1Name)) {
                lines.add(matchesIndex, team1Name);
                matchesIndex++;
            }

            // Add team2 if not exists
            if (!existingTeams.contains(team2Name)) {
                lines.add(matchesIndex, team2Name);
                matchesIndex++;
            }
        }

        // Add the new match at the end of the file
        lines.add(team1Name + "|" + team2Name);
        lines.add(String.join("|", team1Players) + "|");
        lines.add(String.join("|", team2Players) + "|");

        // Add placeholder batting and bowling lines (empty for now)
        lines.add(""); // Team 1 batting lineup
        lines.add(""); // Team 2 bowling stats
        lines.add(""); // Team 2 batting lineup
        lines.add(""); // Team 1 bowling stats

        // Write back to file
        Files.write(filePath, lines);
    }

    private void clearForm() {
        // Clear team names
        team1NameField.clear();
        team2NameField.clear();

        // Clear team 1 players
        TextField[] team1Fields = {
                team1Player1, team1Player2, team1Player3, team1Player4, team1Player5,
                team1Player6, team1Player7, team1Player8, team1Player9, team1Player10, team1Player11
        };

        for (TextField field : team1Fields) {
            field.clear();
        }

        // Clear team 2 players
        TextField[] team2Fields = {
                team2Player1, team2Player2, team2Player3, team2Player4, team2Player5,
                team2Player6, team2Player7, team2Player8, team2Player9, team2Player10, team2Player11
        };

        for (TextField field : team2Fields) {
            field.clear();
        }

        // Clear overs
        oversField.clear();
    }

    private void showSuccessAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
