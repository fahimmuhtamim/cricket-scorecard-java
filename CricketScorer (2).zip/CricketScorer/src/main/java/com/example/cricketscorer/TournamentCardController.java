package com.example.cricketscorer;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class TournamentCardController {

    @FXML private Label tournamentNameLabel;
    @FXML private Label createdDateLabel;
    @FXML private Button openButton;

    private Tournament tournament;
    private String tournamentFileName;

    public void setTournament(Tournament tournament) {
        this.tournament = tournament;
        tournamentNameLabel.setText(tournament.getName());
        createdDateLabel.setText("Created: " + tournament.getCreatedDate());

        // Generate the tournament file name
        this.tournamentFileName = tournament.getName().replaceAll("\\s+", "") + ".txt";

        openButton.setOnAction(e -> openTournamentView(e));
    }

    // Method to set tournament file name explicitly if needed
    public void setTournamentFileName(String fileName) {
        this.tournamentFileName = fileName;
    }

    private void openTournamentView(ActionEvent e) {
        try {
            // Load the FXML and get the controller
            FXMLLoader loader = new FXMLLoader(getClass().getResource("tournament-view.fxml"));
            Parent root = loader.load();

            // Get the controller and pass the tournament data
            TournamentViewController controller = loader.getController();
            controller.setTournament(tournament);
            controller.setTournamentFile(tournamentFileName); // Pass the file name

            // Set up the scene and stage
            Stage stage = (Stage)((Node)e.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}